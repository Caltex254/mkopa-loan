// Loan product definitions
export const LOAN_PRODUCTS = [
  { amount: 5000, processingFee: 299 },
  { amount: 10000, processingFee: 599 },
  { amount: 20000, processingFee: 1199 },
  { amount: 50000, processingFee: 2999 },
  { amount: 100000, processingFee: 5999 },
  { amount: 200000, processingFee: 11999 },
  { amount: 500000, processingFee: 29999 },
];

// Interest rate (simple) for repayment calculation
const INTEREST_RATE = 0.15; // 15%
const LOAN_TERM_DAYS = 30;
const MIN_LOAN_AMOUNT = 5000;
const MAX_LOAN_AMOUNT = 500000;

// Activation fee is always 299
export const ACTIVATION_FEE = 299;

/**
 * Calculate processing fee for any loan amount.
 * For predefined products, use the exact fee.
 * For custom amounts, calculate based on a ~6% rate with interpolation.
 */
export function calculateProcessingFee(loanAmount: number): number {
  // Check if it matches a predefined product exactly
  const exactProduct = LOAN_PRODUCTS.find((p) => p.amount === loanAmount);
  if (exactProduct) return exactProduct.processingFee;

  // For custom amounts, use interpolation between the nearest products
  // Find the two closest predefined products
  const sorted = [...LOAN_PRODUCTS].sort((a, b) => a.amount - b.amount);

  // If below minimum product, use the minimum fee ratio
  if (loanAmount <= sorted[0].amount) {
    return sorted[0].processingFee;
  }

  // If above maximum product, use the maximum fee ratio
  if (loanAmount >= sorted[sorted.length - 1].amount) {
    return Math.ceil(loanAmount * 0.06);
  }

  // Find bracket
  let lower = sorted[0];
  let upper = sorted[sorted.length - 1];

  for (let i = 0; i < sorted.length - 1; i++) {
    if (loanAmount >= sorted[i].amount && loanAmount <= sorted[i + 1].amount) {
      lower = sorted[i];
      upper = sorted[i + 1];
      break;
    }
  }

  // Linear interpolation
  const ratio =
    (loanAmount - lower.amount) / (upper.amount - lower.amount);
  const fee =
    lower.processingFee + ratio * (upper.processingFee - lower.processingFee);

  return Math.ceil(fee);
}

/**
 * Calculate full loan details for any amount >= MIN_LOAN_AMOUNT
 */
export function calculateLoan(loanAmount: number) {
  if (loanAmount < MIN_LOAN_AMOUNT) return null;
  if (loanAmount > MAX_LOAN_AMOUNT) return null;

  const processingFee = calculateProcessingFee(loanAmount);
  const amountReceived = loanAmount - processingFee;
  const interest = loanAmount * INTEREST_RATE;
  const totalRepayment = loanAmount + interest;

  const repaymentDate = new Date();
  repaymentDate.setDate(repaymentDate.getDate() + LOAN_TERM_DAYS);

  return {
    loanAmount,
    processingFee,
    amountReceived,
    totalRepayment,
    repaymentDate: repaymentDate.toISOString().split('T')[0],
    interestRate: INTEREST_RATE * 100,
    loanTermDays: LOAN_TERM_DAYS,
    activationFee: ACTIVATION_FEE,
  };
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-KE', {
    style: 'currency',
    currency: 'KES',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

export { MIN_LOAN_AMOUNT, MAX_LOAN_AMOUNT, INTEREST_RATE, LOAN_TERM_DAYS };
