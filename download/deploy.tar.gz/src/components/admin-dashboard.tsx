'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { useAppStore } from '@/components/store';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import Image from 'next/image';
import {
  LayoutDashboard,
  Users,
  FileText,
  ShieldCheck,
  CreditCard,
  Package,
  Bell,
  BarChart3,
  LogOut,
  Menu,
  X,
  Search,
  ChevronLeft,
  ChevronRight,
  Loader2,
  CheckCircle2,
  XCircle,
  Eye,
  Send,
  TrendingUp,
  UsersRound,
  Banknote,
  AlertCircle,
  DollarSign,
  Clock,
  UserCheck,
  Download,
  Activity,
  UserX,
  FileDown,
  ImageIcon,
  ExternalLink,
  RefreshCw,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
} from 'lucide-react';

// --- Types ---
type Section =
  | 'overview'
  | 'users'
  | 'applications'
  | 'kyc'
  | 'payments'
  | 'products'
  | 'notifications'
  | 'reports'
  | 'activity';

interface AdminStats {
  totalUsers: number;
  totalApplications: number;
  pendingKYC: number;
  pendingReview: number;
  approvedLoans: number;
  rejectedLoans: number;
  totalDisbursed: number;
}

interface AdminUser {
  id: string;
  fullName: string;
  phone: string;
  email: string;
  role: string;
  isActive: boolean;
  createdAt: string;
  kycStatus: string;
  kycVerifiedAt: string | null;
  loanCount: number;
}

interface UserDetail {
  id: string;
  fullName: string;
  phone: string;
  email: string;
  role: string;
  isActive: boolean;
  createdAt: string;
  kyc: {
    id: string;
    legalName: string;
    nationalId: string;
    idFrontImage: string;
    idBackImage: string;
    residentialAddress: string;
    dateOfBirth: string;
    status: string;
    verifiedAt: string | null;
  } | null;
  loanApps: LoanApplication[];
  payments: PaymentRecord[];
  activityLogs: { id: string; action: string; details: string; createdAt: string }[];
}

interface LoanApplication {
  id: string;
  userId: string;
  loanAmount: number;
  processingFee: number;
  amountReceived: number;
  totalRepayment: number;
  repaymentDate: string;
  status: string;
  activationPaid: boolean;
  activationRef: string | null;
  paymentRef: string | null;
  reviewedAt: string | null;
  createdAt: string;
  updatedAt: string;
  user: {
    id: string;
    fullName: string;
    phone: string;
    email: string;
    kyc: { status: string } | null;
  };
}

interface KYCRecord {
  id: string;
  userId: string;
  legalName: string;
  nationalId: string;
  idFrontImage: string;
  idBackImage: string;
  residentialAddress: string;
  dateOfBirth: string;
  status: string;
  verifiedAt: string | null;
  createdAt: string;
  user: {
    id: string;
    fullName: string;
    email: string;
    phone: string;
  };
}

interface PaymentRecord {
  id: string;
  userId: string;
  applicationId: string | null;
  transactionId: string;
  paymentRef: string;
  phoneNumber: string;
  amount: number;
  status: string;
  type: string;
  createdAt: string;
  user: {
    id: string;
    fullName: string;
    phone: string;
    email: string;
  };
}

interface ActivityLog {
  id: string;
  action: string;
  details: string;
  createdAt: string;
  user: {
    fullName: string;
    email: string;
  } | null;
}

interface MonthlyStat {
  month: string;
  applications: number;
  approved: number;
  disbursed: number;
}

interface LoanProduct {
  amount: number;
  processingFee: number;
}

// --- Helper functions ---
function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-KE', {
    style: 'currency',
    currency: 'KES',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

function getStatusColor(status: string): string {
  switch (status) {
    case 'approved':
    case 'verified':
    case 'completed':
      return 'bg-green-100 text-green-800';
    case 'submitted_for_review':
    case 'pending':
    case 'pending_activation':
      return 'bg-yellow-100 text-yellow-800';
    case 'rejected':
      return 'bg-red-100 text-red-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
}

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('en-KE', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

function formatDateTime(dateStr: string): string {
  return new Date(dateStr).toLocaleString('en-KE', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function formatStatus(status: string): string {
  return status
    .split('_')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');
}

// --- Navigation items ---
const NAV_ITEMS: { id: Section; label: string; icon: React.ReactNode }[] = [
  { id: 'overview', label: 'Dashboard Overview', icon: <LayoutDashboard className="size-5" /> },
  { id: 'users', label: 'Users Management', icon: <Users className="size-5" /> },
  { id: 'applications', label: 'Loan Applications', icon: <FileText className="size-5" /> },
  { id: 'kyc', label: 'KYC Verification', icon: <ShieldCheck className="size-5" /> },
  { id: 'payments', label: 'Payment Records', icon: <CreditCard className="size-5" /> },
  { id: 'products', label: 'Loan Products', icon: <Package className="size-5" /> },
  { id: 'activity', label: 'Activity Logs', icon: <Activity className="size-5" /> },
  { id: 'notifications', label: 'Notifications', icon: <Bell className="size-5" /> },
  { id: 'reports', label: 'Reports & Export', icon: <BarChart3 className="size-5" /> },
];

// --- Main Component ---
export default function AdminDashboard() {
  const { user, logout, setView } = useAppStore();
  const [activeSection, setActiveSection] = useState<Section>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  // --- Data states ---
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [monthlyStats, setMonthlyStats] = useState<MonthlyStat[]>([]);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [usersPagination, setUsersPagination] = useState({ page: 1, totalPages: 1, total: 0 });
  const [usersSearch, setUsersSearch] = useState('');
  const [applications, setApplications] = useState<LoanApplication[]>([]);
  const [applicationsPagination, setApplicationsPagination] = useState({
    page: 1,
    totalPages: 1,
    total: 0,
  });
  const [applicationsFilter, setApplicationsFilter] = useState('all');
  const [kycRecords, setKycRecords] = useState<KYCRecord[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [paymentsFilter, setPaymentsFilter] = useState('all');
  const [loanProducts, setLoanProducts] = useState<LoanProduct[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);

  // --- Detail states ---
  const [userDetail, setUserDetail] = useState<UserDetail | null>(null);
  const [userDetailOpen, setUserDetailOpen] = useState(false);
  const [userDetailLoading, setUserDetailLoading] = useState(false);

  // --- Loading states ---
  const [loadingStats, setLoadingStats] = useState(false);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [loadingApplications, setLoadingApplications] = useState(false);
  const [loadingKyc, setLoadingKyc] = useState(false);
  const [loadingPayments, setLoadingPayments] = useState(false);
  const [loadingProducts, setLoadingProducts] = useState(false);
  const [loadingActivity, setLoadingActivity] = useState(false);

  // --- Dialog states ---
  const [reviewDialog, setReviewDialog] = useState<{
    open: boolean;
    applicationId: string;
    action: 'approve' | 'reject';
    applicantName: string;
    amount: number;
  }>({ open: false, applicationId: '', action: 'approve', applicantName: '', amount: 0 });
  const [reviewReason, setReviewReason] = useState('');
  const [reviewLoading, setReviewLoading] = useState(false);

  const [kycDialog, setKycDialog] = useState<{
    open: boolean;
    userId: string;
    action: 'verify' | 'reject';
    name: string;
  }>({ open: false, userId: '', action: 'verify', name: '' });
  const [kycReason, setKycReason] = useState('');
  const [kycLoading, setKycLoading] = useState(false);

  const [kycDetailDialog, setKycDetailDialog] = useState<{
    open: boolean;
    kyc: KYCRecord | null;
  }>({ open: false, kyc: null });

  const [kycImageDialog, setKycImageDialog] = useState<{
    open: boolean;
    imageUrl: string;
    label: string;
    kycId: string;
    side: 'front' | 'back';
  }>({ open: false, imageUrl: '', label: '', kycId: '', side: 'front' });

  const [notifForm, setNotifForm] = useState({ userId: '', title: '', message: '' });
  const [notifLoading, setNotifLoading] = useState(false);
  const [notifSuccess, setNotifSuccess] = useState(false);

  // --- Auth check ---
  useEffect(() => {
    if (!user || user.role !== 'admin') {
      setView('landing');
    }
  }, [user, setView]);

  // --- Fetch functions ---
  const fetchStats = useCallback(async () => {
    setLoadingStats(true);
    try {
      const res = await fetch('/api/admin/stats');
      if (res.ok) {
        const data = await res.json();
        setStats(data);
      }
      // Also fetch monthly stats from reports
      const reportRes = await fetch('/api/admin/reports?type=summary');
      if (reportRes.ok) {
        const reportData = await reportRes.json();
        setMonthlyStats(reportData.monthlyStats || []);
      }
    } catch {
      // silently fail
    } finally {
      setLoadingStats(false);
    }
  }, []);

  const fetchUsers = useCallback(async (page = 1) => {
    setLoadingUsers(true);
    try {
      const res = await fetch(`/api/admin/users?page=${page}&limit=10`);
      if (res.ok) {
        const data = await res.json();
        setUsers(data.users || []);
        setUsersPagination(data.pagination || { page: 1, totalPages: 1, total: 0 });
      }
    } catch {
      // silently fail
    } finally {
      setLoadingUsers(false);
    }
  }, []);

  const fetchApplications = useCallback(async (page = 1, status = '') => {
    setLoadingApplications(true);
    try {
      const statusParam = status && status !== 'all' ? `&status=${status}` : '';
      const res = await fetch(`/api/admin/applications?page=${page}&limit=10${statusParam}`);
      if (res.ok) {
        const data = await res.json();
        setApplications(data.applications || []);
        setApplicationsPagination(
          data.pagination || { page: 1, totalPages: 1, total: 0 }
        );
      }
    } catch {
      // silently fail
    } finally {
      setLoadingApplications(false);
    }
  }, []);

  const fetchKycRecords = useCallback(async () => {
    setLoadingKyc(true);
    try {
      const res = await fetch('/api/admin/kyc');
      if (res.ok) {
        const data = await res.json();
        setKycRecords(data.records || []);
      }
    } catch {
      // silently fail
    } finally {
      setLoadingKyc(false);
    }
  }, []);

  const fetchPayments = useCallback(async () => {
    setLoadingPayments(true);
    try {
      const res = await fetch('/api/admin/payments');
      if (res.ok) {
        const data = await res.json();
        setPayments(data.payments || []);
      }
    } catch {
      // silently fail
    } finally {
      setLoadingPayments(false);
    }
  }, []);

  const fetchLoanProducts = useCallback(async () => {
    setLoadingProducts(true);
    try {
      const res = await fetch('/api/loans/products');
      if (res.ok) {
        const data = await res.json();
        setLoanProducts(data.products || []);
      }
    } catch {
      // silently fail
    } finally {
      setLoadingProducts(false);
    }
  }, []);

  const fetchActivityLogs = useCallback(async () => {
    setLoadingActivity(true);
    try {
      const res = await fetch('/api/admin/reports?type=activity');
      if (res.ok) {
        const data = await res.json();
        setActivityLogs(data.logs || []);
      }
    } catch {
      // silently fail
    } finally {
      setLoadingActivity(false);
    }
  }, []);

  // --- Data fetching on section change ---
  useEffect(() => {
    switch (activeSection) {
      case 'overview':
        fetchStats();
        break;
      case 'users':
        fetchUsers(1);
        break;
      case 'applications':
        fetchApplications(1, applicationsFilter);
        break;
      case 'kyc':
        fetchKycRecords();
        break;
      case 'payments':
        fetchPayments();
        break;
      case 'products':
        fetchLoanProducts();
        break;
      case 'activity':
        fetchActivityLogs();
        break;
    }
  }, [activeSection, fetchStats, fetchUsers, fetchApplications, fetchKycRecords, fetchPayments, fetchLoanProducts, fetchActivityLogs, applicationsFilter]);

  // --- Mutation handlers ---
  const handleReviewApplication = async () => {
    setReviewLoading(true);
    try {
      const res = await fetch(`/api/admin/applications/${reviewDialog.applicationId}/review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: reviewDialog.action,
          reason: reviewReason,
        }),
      });
      if (res.ok) {
        fetchApplications(applicationsPagination.page, applicationsFilter);
        fetchStats();
      }
    } catch {
      // silently fail
    } finally {
      setReviewLoading(false);
      setReviewDialog({ open: false, applicationId: '', action: 'approve', applicantName: '', amount: 0 });
      setReviewReason('');
    }
  };

  const handleVerifyKyc = async () => {
    setKycLoading(true);
    try {
      const res = await fetch(`/api/admin/kyc/${kycDialog.userId}/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: kycDialog.action,
          reason: kycReason,
        }),
      });
      if (res.ok) {
        fetchKycRecords();
        fetchStats();
      }
    } catch {
      // silently fail
    } finally {
      setKycLoading(false);
      setKycDialog({ open: false, userId: '', action: 'verify', name: '' });
      setKycReason('');
    }
  };

  const handleSendNotification = async () => {
    if (!notifForm.userId || !notifForm.title || !notifForm.message) return;
    setNotifLoading(true);
    try {
      const res = await fetch('/api/admin/notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(notifForm),
      });
      if (res.ok) {
        setNotifSuccess(true);
        setNotifForm({ userId: '', title: '', message: '' });
        setTimeout(() => setNotifSuccess(false), 3000);
      }
    } catch {
      // silently fail
    } finally {
      setNotifLoading(false);
    }
  };

  const handleViewUserDetail = async (userId: string) => {
    setUserDetailLoading(true);
    setUserDetailOpen(true);
    try {
      const res = await fetch(`/api/admin/users/${userId}`);
      if (res.ok) {
        const data = await res.json();
        setUserDetail(data.user);
      }
    } catch {
      // silently fail
    } finally {
      setUserDetailLoading(false);
    }
  };

  const handleToggleUserActive = async (userId: string, isActive: boolean) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !isActive }),
      });
      if (res.ok) {
        fetchUsers(usersPagination.page);
        fetchStats();
      }
    } catch {
      // silently fail
    }
  };

  const handleDownloadKycDocument = (kycId: string, side: 'front' | 'back', userName: string) => {
    const url = `/api/admin/kyc/${kycId}/download?side=${side}`;
    const link = document.createElement('a');
    link.href = url;
    link.download = `${userName.replace(/\s+/g, '_')}_ID_${side}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleLogout = () => {
    logout();
    setView('landing');
  };

  // --- Filtered data ---
  const filteredUsers = users.filter((u) => {
    if (!usersSearch) return true;
    const q = usersSearch.toLowerCase();
    return u.fullName.toLowerCase().includes(q) || u.email.toLowerCase().includes(q) || u.phone.includes(q);
  });

  const filteredPayments = payments.filter((p) => {
    if (!paymentsFilter || paymentsFilter === 'all') return true;
    return p.status === paymentsFilter;
  });

  // --- Render sidebar ---
  const renderSidebar = () => (
    <div
      className={`flex flex-col h-full bg-white border-r border-gray-200 transition-all duration-300 ${
        sidebarCollapsed ? 'w-16' : 'w-64'
      }`}
    >
      {/* Logo */}
      <div className="flex items-center gap-2 p-4 border-b border-gray-200">
        <Image src="/logo.png" alt="MKOPA LOAN" width={36} height={36} className="rounded-lg shrink-0" />
        {!sidebarCollapsed && (
          <div className="overflow-hidden">
            <h1 className="text-lg font-bold text-[#333333] whitespace-nowrap">MKOPA LOAN</h1>
            <p className="text-xs text-gray-500 whitespace-nowrap">Admin Panel</p>
          </div>
        )}
      </div>

      {/* Navigation */}
      <ScrollArea className="flex-1">
        <nav className="flex flex-col gap-1 p-2">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveSection(item.id);
                setSidebarOpen(false);
              }}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                activeSection === item.id
                  ? 'bg-[#00A651]/10 text-[#00A651]'
                  : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
              }`}
              title={sidebarCollapsed ? item.label : undefined}
            >
              <span className="shrink-0">{item.icon}</span>
              {!sidebarCollapsed && <span className="whitespace-nowrap">{item.label}</span>}
            </button>
          ))}
        </nav>
      </ScrollArea>

      {/* Collapse toggle */}
      <div className="border-t border-gray-200 p-2 hidden lg:block">
        <button
          onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          className="flex items-center justify-center w-full px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition-colors cursor-pointer"
        >
          {sidebarCollapsed ? <ChevronRight className="size-5" /> : <ChevronLeft className="size-5" />}
          {!sidebarCollapsed && <span className="ml-2 text-sm">Collapse</span>}
        </button>
      </div>

      {/* Logout */}
      <div className="border-t border-gray-200 p-2">
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-red-600 hover:bg-red-50 transition-colors w-full cursor-pointer"
        >
          <LogOut className="size-5 shrink-0" />
          {!sidebarCollapsed && <span>Logout</span>}
        </button>
      </div>
    </div>
  );

  // --- Mini Bar Chart Component ---
  function MiniBarChart({ data, dataKey, label }: { data: MonthlyStat[]; dataKey: 'applications' | 'approved' | 'disbursed'; label: string }) {
    if (!data.length) return null;
    const maxVal = Math.max(...data.map((d) => d[dataKey]), 1);
    return (
      <div className="space-y-2">
        <p className="text-xs font-semibold text-gray-500 uppercase">{label}</p>
        <div className="flex items-end gap-1.5 h-24">
          {data.map((d, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-1">
              <div
                className="w-full rounded-t bg-[#00A651] transition-all duration-500 min-h-[2px]"
                style={{ height: `${(d[dataKey] / maxVal) * 100}%` }}
              />
              <span className="text-[9px] text-gray-400 truncate w-full text-center">{d.month.split(' ')[0]}</span>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  // OVERVIEW SECTION
  // ═══════════════════════════════════════════════════════════════════════
  const renderOverview = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-[#333333]">Dashboard Overview</h2>
          <p className="text-gray-500 mt-1">Welcome back, {user?.fullName || 'Admin'}</p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => fetchStats()}
          className="text-[#00A651] border-[#00A651]/30 hover:bg-[#00A651]/10 cursor-pointer"
        >
          <RefreshCw className="size-3.5 mr-1" />
          Refresh
        </Button>
      </div>

      {/* Stats Grid */}
      {loadingStats ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="size-8 animate-spin text-[#00A651]" />
        </div>
      ) : stats ? (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="border-l-4 border-l-[#00A651]">
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-medium uppercase tracking-wide text-gray-500">Total Users</p>
                    <p className="text-2xl font-bold text-[#333333] mt-1">{stats.totalUsers}</p>
                  </div>
                  <div className="flex items-center justify-center size-12 rounded-xl bg-[#00A651]/10">
                    <Users className="size-6 text-[#00A651]" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-blue-500">
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-medium uppercase tracking-wide text-gray-500">Applications</p>
                    <p className="text-2xl font-bold text-[#333333] mt-1">{stats.totalApplications}</p>
                  </div>
                  <div className="flex items-center justify-center size-12 rounded-xl bg-blue-50">
                    <FileText className="size-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-green-500">
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-medium uppercase tracking-wide text-gray-500">Approved</p>
                    <p className="text-2xl font-bold text-[#333333] mt-1">{stats.approvedLoans}</p>
                  </div>
                  <div className="flex items-center justify-center size-12 rounded-xl bg-green-50">
                    <CheckCircle2 className="size-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-yellow-500">
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-medium uppercase tracking-wide text-gray-500">Total Disbursed</p>
                    <p className="text-2xl font-bold text-[#333333] mt-1">{formatCurrency(stats.totalDisbursed)}</p>
                  </div>
                  <div className="flex items-center justify-center size-12 rounded-xl bg-[#00A651]/10">
                    <DollarSign className="size-6 text-[#00A651]" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Secondary stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-5 flex items-center gap-4">
                <div className="flex items-center justify-center size-10 rounded-lg bg-yellow-50">
                  <ShieldCheck className="size-5 text-yellow-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-500">Pending KYC</p>
                  <p className="text-xl font-bold text-[#333333]">{stats.pendingKYC}</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-5 flex items-center gap-4">
                <div className="flex items-center justify-center size-10 rounded-lg bg-orange-50">
                  <Clock className="size-5 text-orange-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-500">Pending Review</p>
                  <p className="text-xl font-bold text-[#333333]">{stats.pendingReview}</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-5 flex items-center gap-4">
                <div className="flex items-center justify-center size-10 rounded-lg bg-red-50">
                  <XCircle className="size-5 text-red-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-500">Rejected Loans</p>
                  <p className="text-xl font-bold text-[#333333]">{stats.rejectedLoans}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Monthly Applications</CardTitle>
              </CardHeader>
              <CardContent>
                <MiniBarChart data={monthlyStats} dataKey="applications" label="Applications per Month" />
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Monthly Disbursements</CardTitle>
              </CardHeader>
              <CardContent>
                <MiniBarChart data={monthlyStats} dataKey="disbursed" label="Amount Disbursed" />
              </CardContent>
            </Card>
          </div>

          {/* Approval Rate */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Loan Approval Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Approval Rate</span>
                  <span className="font-bold text-[#00A651]">
                    {stats.totalApplications > 0
                      ? Math.round((stats.approvedLoans / stats.totalApplications) * 100)
                      : 0}%
                  </span>
                </div>
                <Progress
                  value={stats.totalApplications > 0 ? (stats.approvedLoans / stats.totalApplications) * 100 : 0}
                  className="h-3"
                />
                <div className="flex justify-between text-xs text-gray-400">
                  <span>{stats.approvedLoans} approved</span>
                  <span>{stats.rejectedLoans} rejected</span>
                  <span>{stats.totalApplications} total</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      ) : (
        <Card>
          <CardContent className="p-6 text-center text-gray-500">
            <AlertCircle className="size-8 mx-auto mb-2 text-gray-400" />
            Failed to load dashboard stats
          </CardContent>
        </Card>
      )}

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Recent Loan Applications</CardTitle>
          <CardDescription>Latest applications submitted</CardDescription>
        </CardHeader>
        <CardContent>
          {loadingApplications ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="size-6 animate-spin text-[#00A651]" />
            </div>
          ) : applications.length > 0 ? (
            <div className="space-y-3">
              {applications.slice(0, 5).map((app) => (
                <div
                  key={app.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Avatar className="size-9">
                      <AvatarFallback className="bg-[#00A651] text-white text-xs">
                        {app.user.fullName.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium text-[#333333]">{app.user.fullName}</p>
                      <p className="text-xs text-gray-500">{formatDate(app.createdAt)}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-semibold text-[#333333]">
                      {formatCurrency(app.loanAmount)}
                    </span>
                    <Badge className={getStatusColor(app.status)} variant="secondary">
                      {formatStatus(app.status)}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-500 text-center py-4">No applications yet</p>
          )}
        </CardContent>
      </Card>
    </div>
  );

  // ═══════════════════════════════════════════════════════════════════════
  // USERS MANAGEMENT SECTION
  // ═══════════════════════════════════════════════════════════════════════
  const renderUsers = () => (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-[#333333]">Users Management</h2>
          <p className="text-gray-500 mt-1">{usersPagination.total} total users</p>
        </div>
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
          <Input
            placeholder="Search by name, email, or phone..."
            value={usersSearch}
            onChange={(e) => setUsersSearch(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          {loadingUsers ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="size-8 animate-spin text-[#00A651]" />
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User</TableHead>
                      <TableHead className="hidden md:table-cell">Phone</TableHead>
                      <TableHead>KYC</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="hidden sm:table-cell">Loans</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsers.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                          No users found
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredUsers.map((u) => (
                        <TableRow key={u.id}>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Avatar className="size-8">
                                <AvatarFallback className="bg-[#00A651] text-white text-xs">
                                  {u.fullName.charAt(0).toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-medium text-sm">{u.fullName}</p>
                                <p className="text-xs text-gray-500">{u.email}</p>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="hidden md:table-cell text-sm text-gray-600">
                            {u.phone}
                          </TableCell>
                          <TableCell>
                            <Badge className={getStatusColor(u.kycStatus)} variant="secondary">
                              {formatStatus(u.kycStatus)}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge
                              className={u.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}
                              variant="secondary"
                            >
                              {u.isActive ? 'Active' : 'Inactive'}
                            </Badge>
                          </TableCell>
                          <TableCell className="hidden sm:table-cell text-sm text-gray-600">
                            {u.loanCount}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <Button
                                size="sm"
                                variant="outline"
                                className="h-7 text-xs cursor-pointer"
                                onClick={() => handleViewUserDetail(u.id)}
                              >
                                <Eye className="size-3 mr-0.5" />
                                View
                              </Button>
                              <Button
                                size="sm"
                                variant={u.isActive ? 'destructive' : 'default'}
                                className={`h-7 text-xs cursor-pointer ${
                                  u.isActive ? '' : 'bg-[#00A651] hover:bg-[#008f45] text-white'
                                }`}
                                onClick={() => handleToggleUserActive(u.id, u.isActive)}
                              >
                                {u.isActive ? (
                                  <><UserX className="size-3 mr-0.5" />Deactivate</>
                                ) : (
                                  <><UserCheck className="size-3 mr-0.5" />Activate</>
                                )}
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>

              {/* Pagination */}
              {usersPagination.totalPages > 1 && (
                <div className="flex items-center justify-between px-4 py-3 border-t">
                  <p className="text-sm text-gray-500">
                    Page {usersPagination.page} of {usersPagination.totalPages}
                  </p>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={usersPagination.page <= 1}
                      onClick={() => fetchUsers(usersPagination.page - 1)}
                    >
                      Previous
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={usersPagination.page >= usersPagination.totalPages}
                      onClick={() => fetchUsers(usersPagination.page + 1)}
                    >
                      Next
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* User Detail Dialog */}
      <Dialog open={userDetailOpen} onOpenChange={setUserDetailOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>User Details</DialogTitle>
          </DialogHeader>
          {userDetailLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="size-8 animate-spin text-[#00A651]" />
            </div>
          ) : userDetail ? (
            <div className="space-y-6">
              {/* User Info */}
              <div className="flex items-center gap-4">
                <Avatar className="size-14">
                  <AvatarFallback className="bg-[#00A651] text-white text-xl">
                    {userDetail.fullName.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-lg font-bold text-[#333333]">{userDetail.fullName}</h3>
                  <p className="text-sm text-gray-500">{userDetail.email}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge
                      className={userDetail.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}
                      variant="secondary"
                    >
                      {userDetail.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                    <span className="text-xs text-gray-400">Joined {formatDate(userDetail.createdAt)}</span>
                  </div>
                </div>
              </div>

              <Separator />

              {/* KYC Info */}
              <div>
                <h4 className="font-semibold text-sm text-gray-700 mb-3">KYC Information</h4>
                {userDetail.kyc ? (
                  <div className="space-y-2">
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="bg-gray-50 rounded-lg p-3">
                        <p className="text-xs text-gray-500">Legal Name</p>
                        <p className="font-medium">{userDetail.kyc.legalName}</p>
                      </div>
                      <div className="bg-gray-50 rounded-lg p-3">
                        <p className="text-xs text-gray-500">National ID</p>
                        <p className="font-medium">{userDetail.kyc.nationalId}</p>
                      </div>
                      <div className="bg-gray-50 rounded-lg p-3">
                        <p className="text-xs text-gray-500">Date of Birth</p>
                        <p className="font-medium">{userDetail.kyc.dateOfBirth}</p>
                      </div>
                      <div className="bg-gray-50 rounded-lg p-3">
                        <p className="text-xs text-gray-500">Status</p>
                        <Badge className={getStatusColor(userDetail.kyc.status)} variant="secondary">
                          {formatStatus(userDetail.kyc.status)}
                        </Badge>
                      </div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-3">
                      <p className="text-xs text-gray-500 mb-1">Address</p>
                      <p className="text-sm">{userDetail.kyc.residentialAddress}</p>
                    </div>
                    {/* Download KYC Documents */}
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-[#00A651] border-[#00A651]/30 cursor-pointer"
                        onClick={() => handleDownloadKycDocument(userDetail.kyc!.id, 'front', userDetail.kyc!.legalName)}
                      >
                        <Download className="size-3.5 mr-1" />
                        Download ID Front
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-[#00A651] border-[#00A651]/30 cursor-pointer"
                        onClick={() => handleDownloadKycDocument(userDetail.kyc!.id, 'back', userDetail.kyc!.legalName)}
                      >
                        <Download className="size-3.5 mr-1" />
                        Download ID Back
                      </Button>
                    </div>
                  </div>
                ) : (
                  <p className="text-sm text-gray-400">No KYC submission</p>
                )}
              </div>

              <Separator />

              {/* Loan History */}
              <div>
                <h4 className="font-semibold text-sm text-gray-700 mb-3">Loan Applications ({userDetail.loanApps.length})</h4>
                {userDetail.loanApps.length === 0 ? (
                  <p className="text-sm text-gray-400">No loan applications</p>
                ) : (
                  <div className="space-y-2">
                    {userDetail.loanApps.slice(0, 5).map((loan) => (
                      <div key={loan.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="text-sm font-medium">{formatCurrency(loan.loanAmount)}</p>
                          <p className="text-xs text-gray-500">{formatDate(loan.createdAt)}</p>
                        </div>
                        <Badge className={getStatusColor(loan.status)} variant="secondary">
                          {formatStatus(loan.status)}
                        </Badge>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <Separator />

              {/* Activity Log */}
              <div>
                <h4 className="font-semibold text-sm text-gray-700 mb-3">Recent Activity</h4>
                {userDetail.activityLogs.length === 0 ? (
                  <p className="text-sm text-gray-400">No activity recorded</p>
                ) : (
                  <div className="space-y-1.5">
                    {userDetail.activityLogs.slice(0, 5).map((log) => (
                      <div key={log.id} className="flex items-start gap-2 text-sm">
                        <Activity className="size-3.5 mt-1 text-gray-400 shrink-0" />
                        <div>
                          <p className="text-gray-700">{log.details}</p>
                          <p className="text-xs text-gray-400">{formatDateTime(log.createdAt)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <p className="text-center text-gray-500">User not found</p>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );

  // ═══════════════════════════════════════════════════════════════════════
  // LOAN APPLICATIONS SECTION
  // ═══════════════════════════════════════════════════════════════════════
  const renderApplications = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-[#333333]">Loan Applications</h2>
        <p className="text-gray-500 mt-1">Review and manage loan applications</p>
      </div>

      <Tabs
        value={applicationsFilter}
        onValueChange={(v) => {
          setApplicationsFilter(v);
          setApplicationsPagination({ ...applicationsPagination, page: 1 });
        }}
      >
        <TabsList>
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="submitted_for_review">Pending Review</TabsTrigger>
          <TabsTrigger value="pending_activation">Pending Activation</TabsTrigger>
          <TabsTrigger value="approved">Approved</TabsTrigger>
          <TabsTrigger value="rejected">Rejected</TabsTrigger>
        </TabsList>

        <TabsContent value={applicationsFilter} className="mt-4">
          <Card>
            <CardContent className="p-0">
              {loadingApplications ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="size-8 animate-spin text-[#00A651]" />
                </div>
              ) : (
                <>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Applicant</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Fee</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="hidden sm:table-cell">Date</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {applications.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                              No applications found
                            </TableCell>
                          </TableRow>
                        ) : (
                          applications.map((app) => (
                            <TableRow key={app.id}>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <Avatar className="size-8">
                                    <AvatarFallback className="bg-[#00A651] text-white text-xs">
                                      {app.user.fullName.charAt(0).toUpperCase()}
                                    </AvatarFallback>
                                  </Avatar>
                                  <div>
                                    <p className="text-sm font-medium">{app.user.fullName}</p>
                                    <p className="text-xs text-gray-500">{app.user.phone}</p>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell className="font-semibold text-sm">
                                {formatCurrency(app.loanAmount)}
                              </TableCell>
                              <TableCell className="text-sm text-red-500">
                                {formatCurrency(app.processingFee)}
                              </TableCell>
                              <TableCell>
                                <Badge className={getStatusColor(app.status)} variant="secondary">
                                  {formatStatus(app.status)}
                                </Badge>
                              </TableCell>
                              <TableCell className="hidden sm:table-cell text-sm text-gray-600">
                                {formatDate(app.createdAt)}
                              </TableCell>
                              <TableCell>
                                {app.status === 'submitted_for_review' ? (
                                  <div className="flex gap-1">
                                    <Button
                                      size="sm"
                                      className="bg-[#00A651] hover:bg-[#008f45] text-white h-8 text-xs cursor-pointer"
                                      onClick={() =>
                                        setReviewDialog({
                                          open: true,
                                          applicationId: app.id,
                                          action: 'approve',
                                          applicantName: app.user.fullName,
                                          amount: app.loanAmount,
                                        })
                                      }
                                    >
                                      <CheckCircle2 className="size-3.5 mr-1" />
                                      Approve
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="destructive"
                                      className="h-8 text-xs cursor-pointer"
                                      onClick={() =>
                                        setReviewDialog({
                                          open: true,
                                          applicationId: app.id,
                                          action: 'reject',
                                          applicantName: app.user.fullName,
                                          amount: app.loanAmount,
                                        })
                                      }
                                    >
                                      <XCircle className="size-3.5 mr-1" />
                                      Reject
                                    </Button>
                                  </div>
                                ) : (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="h-8 text-xs cursor-pointer"
                                    onClick={() => handleViewUserDetail(app.userId)}
                                  >
                                    <Eye className="size-3 mr-1" />
                                    View User
                                  </Button>
                                )}
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>

                  {/* Pagination */}
                  {applicationsPagination.totalPages > 1 && (
                    <div className="flex items-center justify-between px-4 py-3 border-t">
                      <p className="text-sm text-gray-500">
                        Page {applicationsPagination.page} of {applicationsPagination.totalPages}
                      </p>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          disabled={applicationsPagination.page <= 1}
                          onClick={() =>
                            fetchApplications(applicationsPagination.page - 1, applicationsFilter)
                          }
                        >
                          Previous
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          disabled={applicationsPagination.page >= applicationsPagination.totalPages}
                          onClick={() =>
                            fetchApplications(applicationsPagination.page + 1, applicationsFilter)
                          }
                        >
                          Next
                        </Button>
                      </div>
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Review Confirmation Dialog */}
      <AlertDialog
        open={reviewDialog.open}
        onOpenChange={(open) => {
          if (!open) {
            setReviewDialog({
              open: false,
              applicationId: '',
              action: 'approve',
              applicantName: '',
              amount: 0,
            });
            setReviewReason('');
          }
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {reviewDialog.action === 'approve' ? 'Approve' : 'Reject'} Loan Application
            </AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to {reviewDialog.action} the loan application from{' '}
              <strong>{reviewDialog.applicantName}</strong> for{' '}
              <strong>{formatCurrency(reviewDialog.amount)}</strong>?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-2">
            <Label htmlFor="review-reason">Reason (optional)</Label>
            <Textarea
              id="review-reason"
              placeholder={`Reason for ${reviewDialog.action}...`}
              value={reviewReason}
              onChange={(e) => setReviewReason(e.target.value)}
            />
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={reviewLoading}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleReviewApplication}
              disabled={reviewLoading}
              className={
                reviewDialog.action === 'approve'
                  ? 'bg-[#00A651] hover:bg-[#008f45] text-white'
                  : 'bg-red-600 hover:bg-red-700 text-white'
              }
            >
              {reviewLoading ? <Loader2 className="size-4 animate-spin mr-2" /> : null}
              {reviewDialog.action === 'approve' ? 'Approve' : 'Reject'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );

  // ═══════════════════════════════════════════════════════════════════════
  // KYC VERIFICATION SECTION (with document download)
  // ═══════════════════════════════════════════════════════════════════════
  const renderKyc = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-[#333333]">KYC Verification</h2>
        <p className="text-gray-500 mt-1">Review and verify user identity documents</p>
      </div>

      <Card>
        <CardContent className="p-0">
          {loadingKyc ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="size-8 animate-spin text-[#00A651]" />
            </div>
          ) : kycRecords.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <ShieldCheck className="size-12 mx-auto mb-3 text-gray-300" />
              <p>No KYC submissions found</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>National ID</TableHead>
                    <TableHead className="hidden md:table-cell">DOB</TableHead>
                    <TableHead className="hidden md:table-cell">Submitted</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {kycRecords.map((kyc) => (
                    <TableRow key={kyc.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Avatar className="size-8">
                            <AvatarFallback className="bg-[#00A651] text-white text-xs">
                              {kyc.legalName.charAt(0).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="text-sm font-medium">{kyc.legalName}</p>
                            <p className="text-xs text-gray-500">{kyc.user.email}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-gray-600">{kyc.nationalId}</TableCell>
                      <TableCell className="hidden md:table-cell text-sm text-gray-600">{kyc.dateOfBirth}</TableCell>
                      <TableCell className="hidden md:table-cell text-sm text-gray-600">
                        {formatDate(kyc.createdAt)}
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(kyc.status)} variant="secondary">
                          {formatStatus(kyc.status)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 text-xs cursor-pointer"
                            onClick={() => setKycDetailDialog({ open: true, kyc })}
                          >
                            <Eye className="size-3 mr-0.5" />
                            View
                          </Button>
                          {kyc.status === 'pending' && (
                            <>
                              <Button
                                size="sm"
                                className="bg-[#00A651] hover:bg-[#008f45] text-white h-7 text-xs cursor-pointer"
                                onClick={() =>
                                  setKycDialog({ open: true, userId: kyc.userId, action: 'verify', name: kyc.legalName })
                                }
                              >
                                <CheckCircle2 className="size-3 mr-0.5" />
                                Verify
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                className="h-7 text-xs cursor-pointer"
                                onClick={() =>
                                  setKycDialog({ open: true, userId: kyc.userId, action: 'reject', name: kyc.legalName })
                                }
                              >
                                <XCircle className="size-3 mr-0.5" />
                              </Button>
                            </>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* KYC Detail Dialog with Document Download */}
      <Dialog
        open={kycDetailDialog.open}
        onOpenChange={(open) => setKycDetailDialog({ open, kyc: null })}
      >
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>KYC Document Details</DialogTitle>
            <DialogDescription>
              Review identity documents for {kycDetailDialog.kyc?.legalName}
            </DialogDescription>
          </DialogHeader>
          {kycDetailDialog.kyc && (
            <div className="space-y-5">
              {/* Personal Info */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-xs text-gray-500">Legal Name</p>
                  <p className="font-medium text-sm">{kycDetailDialog.kyc.legalName}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-xs text-gray-500">National ID</p>
                  <p className="font-medium text-sm">{kycDetailDialog.kyc.nationalId}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-xs text-gray-500">Date of Birth</p>
                  <p className="font-medium text-sm">{kycDetailDialog.kyc.dateOfBirth}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-xs text-gray-500">Status</p>
                  <Badge className={getStatusColor(kycDetailDialog.kyc.status)} variant="secondary">
                    {formatStatus(kycDetailDialog.kyc.status)}
                  </Badge>
                </div>
              </div>
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-500">Residential Address</p>
                <p className="font-medium text-sm">{kycDetailDialog.kyc.residentialAddress}</p>
              </div>

              <Separator />

              {/* ID Front Image */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-semibold flex items-center gap-1">
                    <ImageIcon className="size-4 text-[#00A651]" />
                    ID Front Image
                  </Label>
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-[#00A651] border-[#00A651]/30 h-7 text-xs cursor-pointer"
                    onClick={() =>
                      handleDownloadKycDocument(
                        kycDetailDialog.kyc!.id,
                        'front',
                        kycDetailDialog.kyc!.legalName
                      )
                    }
                  >
                    <Download className="size-3 mr-1" />
                    Download
                  </Button>
                </div>
                <div
                  className="rounded-lg border overflow-hidden cursor-pointer hover:opacity-90 transition-opacity"
                  onClick={() =>
                    setKycImageDialog({
                      open: true,
                      imageUrl: kycDetailDialog.kyc!.idFrontImage,
                      label: 'ID Front',
                      kycId: kycDetailDialog.kyc!.id,
                      side: 'front',
                    })
                  }
                >
                  <img
                    src={kycDetailDialog.kyc.idFrontImage}
                    alt="ID Front"
                    className="w-full max-h-48 object-cover"
                  />
                </div>
              </div>

              {/* ID Back Image */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-semibold flex items-center gap-1">
                    <ImageIcon className="size-4 text-[#00A651]" />
                    ID Back Image
                  </Label>
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-[#00A651] border-[#00A651]/30 h-7 text-xs cursor-pointer"
                    onClick={() =>
                      handleDownloadKycDocument(
                        kycDetailDialog.kyc!.id,
                        'back',
                        kycDetailDialog.kyc!.legalName
                      )
                    }
                  >
                    <Download className="size-3 mr-1" />
                    Download
                  </Button>
                </div>
                <div
                  className="rounded-lg border overflow-hidden cursor-pointer hover:opacity-90 transition-opacity"
                  onClick={() =>
                    setKycImageDialog({
                      open: true,
                      imageUrl: kycDetailDialog.kyc!.idBackImage,
                      label: 'ID Back',
                      kycId: kycDetailDialog.kyc!.id,
                      side: 'back',
                    })
                  }
                >
                  <img
                    src={kycDetailDialog.kyc.idBackImage}
                    alt="ID Back"
                    className="w-full max-h-48 object-cover"
                  />
                </div>
              </div>

              {/* Actions */}
              {kycDetailDialog.kyc.status === 'pending' && (
                <div className="flex gap-2 pt-2">
                  <Button
                    className="flex-1 bg-[#00A651] hover:bg-[#008f45] text-white cursor-pointer"
                    onClick={() => {
                      setKycDetailDialog({ open: false, kyc: null });
                      setKycDialog({
                        open: true,
                        userId: kycDetailDialog.kyc!.userId,
                        action: 'verify',
                        name: kycDetailDialog.kyc!.legalName,
                      });
                    }}
                  >
                    <CheckCircle2 className="size-4 mr-1" />
                    Approve & Verify
                  </Button>
                  <Button
                    variant="destructive"
                    className="flex-1 cursor-pointer"
                    onClick={() => {
                      setKycDetailDialog({ open: false, kyc: null });
                      setKycDialog({
                        open: true,
                        userId: kycDetailDialog.kyc!.userId,
                        action: 'reject',
                        name: kycDetailDialog.kyc!.legalName,
                      });
                    }}
                  >
                    <XCircle className="size-4 mr-1" />
                    Reject
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* KYC Image Preview Dialog */}
      <Dialog
        open={kycImageDialog.open}
        onOpenChange={(open) =>
          setKycImageDialog({ open, imageUrl: '', label: '', kycId: '', side: 'front' })
        }
      >
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>{kycImageDialog.label}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="rounded-lg border overflow-hidden bg-gray-50">
              <img
                src={kycImageDialog.imageUrl}
                alt={kycImageDialog.label}
                className="w-full max-h-[60vh] object-contain"
              />
            </div>
            <Button
              className="w-full bg-[#00A651] hover:bg-[#008f45] text-white cursor-pointer"
              onClick={() =>
                handleDownloadKycDocument(
                  kycImageDialog.kycId,
                  kycImageDialog.side,
                  'document'
                )
              }
            >
              <Download className="size-4 mr-2" />
              Download {kycImageDialog.label}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* KYC Verify/Reject Confirmation */}
      <AlertDialog
        open={kycDialog.open}
        onOpenChange={(open) => {
          if (!open) {
            setKycDialog({ open: false, userId: '', action: 'verify', name: '' });
            setKycReason('');
          }
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {kycDialog.action === 'verify' ? 'Verify' : 'Reject'} KYC
            </AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to {kycDialog.action === 'verify' ? 'approve' : 'reject'} the KYC
              verification for <strong>{kycDialog.name}</strong>?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-2">
            <Label htmlFor="kyc-reason">Reason (optional)</Label>
            <Textarea
              id="kyc-reason"
              placeholder={`Reason for ${kycDialog.action}...`}
              value={kycReason}
              onChange={(e) => setKycReason(e.target.value)}
            />
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={kycLoading}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleVerifyKyc}
              disabled={kycLoading}
              className={
                kycDialog.action === 'verify'
                  ? 'bg-[#00A651] hover:bg-[#008f45] text-white'
                  : 'bg-red-600 hover:bg-red-700 text-white'
              }
            >
              {kycLoading ? <Loader2 className="size-4 animate-spin mr-2" /> : null}
              {kycDialog.action === 'verify' ? 'Verify' : 'Reject'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );

  // ═══════════════════════════════════════════════════════════════════════
  // PAYMENTS SECTION
  // ═══════════════════════════════════════════════════════════════════════
  const renderPayments = () => (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-[#333333]">Payment Records</h2>
          <p className="text-gray-500 mt-1">Track all STK Push payments and transactions</p>
        </div>
        <Select value={paymentsFilter} onValueChange={setPaymentsFilter}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Filter" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="failed">Failed</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardContent className="p-0">
          {loadingPayments ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="size-8 animate-spin text-[#00A651]" />
            </div>
          ) : filteredPayments.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <CreditCard className="size-12 mx-auto mb-3 text-gray-300" />
              <p>No payment records found</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Transaction ID</TableHead>
                    <TableHead>Phone</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="hidden md:table-cell">Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPayments.map((p) => (
                    <TableRow key={p.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Avatar className="size-7">
                            <AvatarFallback className="bg-[#00A651] text-white text-[10px]">
                              {p.user.fullName.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                          <span className="text-sm font-medium">{p.user.fullName}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-xs font-mono text-gray-600">{p.transactionId}</TableCell>
                      <TableCell className="text-sm text-gray-600">{p.phoneNumber}</TableCell>
                      <TableCell className="font-semibold text-sm">{formatCurrency(p.amount)}</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="bg-blue-50 text-blue-700">
                          {p.type}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(p.status)} variant="secondary">
                          {formatStatus(p.status)}
                        </Badge>
                      </TableCell>
                      <TableCell className="hidden md:table-cell text-sm text-gray-600">
                        {formatDate(p.createdAt)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );

  // ═══════════════════════════════════════════════════════════════════════
  // LOAN PRODUCTS SECTION
  // ═══════════════════════════════════════════════════════════════════════
  const renderProducts = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-[#333333]">Loan Products</h2>
        <p className="text-gray-500 mt-1">Manage available loan products and pricing</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {loanProducts.map((product) => (
          <Card key={product.amount} className="border-l-4 border-l-[#00A651]">
            <CardContent className="p-5">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold text-[#333333]">
                    {formatCurrency(product.amount)}
                  </h3>
                  <Badge className="bg-[#00A651]/10 text-[#00A651]">Active</Badge>
                </div>
                <Separator />
                <div className="space-y-1.5 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Processing Fee</span>
                    <span className="font-semibold text-red-500">{formatCurrency(product.processingFee)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Amount Received</span>
                    <span className="font-semibold text-[#00A651]">
                      {formatCurrency(product.amount - product.processingFee)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Interest (15%)</span>
                    <span className="font-semibold">{formatCurrency(product.amount * 0.15)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Total Repayment</span>
                    <span className="font-bold">{formatCurrency(product.amount * 1.15)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Fee Ratio</span>
                    <span className="font-semibold">{((product.processingFee / product.amount) * 100).toFixed(1)}%</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  // ═══════════════════════════════════════════════════════════════════════
  // ACTIVITY LOGS SECTION
  // ═══════════════════════════════════════════════════════════════════════
  const renderActivity = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-[#333333]">Activity Logs</h2>
        <p className="text-gray-500 mt-1">Track all user and system activities</p>
      </div>

      <Card>
        <CardContent className="p-0">
          {loadingActivity ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="size-8 animate-spin text-[#00A651]" />
            </div>
          ) : activityLogs.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <Activity className="size-12 mx-auto mb-3 text-gray-300" />
              <p>No activity logs found</p>
            </div>
          ) : (
            <div className="divide-y">
              {activityLogs.map((log) => (
                <div key={log.id} className="flex items-start gap-3 p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-center size-8 rounded-full bg-gray-100 shrink-0 mt-0.5">
                    <Activity className="size-4 text-gray-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge variant="secondary" className="text-xs">
                        {log.action.replace(/_/g, ' ')}
                      </Badge>
                      {log.user && (
                        <span className="text-xs text-gray-500">{log.user.fullName}</span>
                      )}
                    </div>
                    <p className="text-sm text-gray-700 mt-1">{log.details}</p>
                    <p className="text-xs text-gray-400 mt-1">{formatDateTime(log.createdAt)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );

  // ═══════════════════════════════════════════════════════════════════════
  // NOTIFICATIONS SECTION
  // ═══════════════════════════════════════════════════════════════════════
  const renderNotifications = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-[#333333]">Send Notifications</h2>
        <p className="text-gray-500 mt-1">Send notifications to users</p>
      </div>

      {notifSuccess && (
        <div className="p-3 rounded-lg bg-green-50 border border-green-200 text-green-700 text-sm flex items-center gap-2">
          <CheckCircle2 className="size-4 shrink-0" />
          Notification sent successfully!
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Send Notification</CardTitle>
          <CardDescription>Send a notification to a specific user</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Select User</Label>
            <Select
              value={notifForm.userId}
              onValueChange={(v) => setNotifForm({ ...notifForm, userId: v })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Choose a user" />
              </SelectTrigger>
              <SelectContent>
                {users.map((u) => (
                  <SelectItem key={u.id} value={u.id}>
                    {u.fullName} ({u.email})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Title</Label>
            <Input
              placeholder="Notification title"
              value={notifForm.title}
              onChange={(e) => setNotifForm({ ...notifForm, title: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label>Message</Label>
            <Textarea
              placeholder="Notification message"
              rows={4}
              value={notifForm.message}
              onChange={(e) => setNotifForm({ ...notifForm, message: e.target.value })}
            />
          </div>
          <Button
            onClick={handleSendNotification}
            disabled={notifLoading || !notifForm.userId || !notifForm.title || !notifForm.message}
            className="bg-[#00A651] hover:bg-[#008f45] text-white cursor-pointer"
          >
            {notifLoading ? <Loader2 className="size-4 animate-spin mr-2" /> : <Send className="size-4 mr-2" />}
            Send Notification
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  // ═══════════════════════════════════════════════════════════════════════
  // REPORTS & EXPORT SECTION
  // ═══════════════════════════════════════════════════════════════════════
  const renderReports = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-[#333333]">Reports & Export</h2>
        <p className="text-gray-500 mt-1">Generate and download reports</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-6 flex flex-col items-center text-center gap-4">
            <div className="flex items-center justify-center size-14 rounded-xl bg-blue-50">
              <Users className="size-7 text-blue-600" />
            </div>
            <div>
              <h3 className="font-semibold text-[#333333]">Users Report</h3>
              <p className="text-sm text-gray-500 mt-1">Export all user data including KYC status</p>
            </div>
            <Button
              variant="outline"
              className="w-full cursor-pointer"
              onClick={async () => {
                try {
                  const res = await fetch('/api/admin/reports?type=users');
                  if (res.ok) {
                    const data = await res.json();
                    downloadJSON(data.users, 'users_report');
                  }
                } catch { /* silently fail */ }
              }}
            >
              <FileDown className="size-4 mr-2" />
              Export Users
            </Button>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-6 flex flex-col items-center text-center gap-4">
            <div className="flex items-center justify-center size-14 rounded-xl bg-[#00A651]/10">
              <FileText className="size-7 text-[#00A651]" />
            </div>
            <div>
              <h3 className="font-semibold text-[#333333]">Loans Report</h3>
              <p className="text-sm text-gray-500 mt-1">Export all loan applications and status</p>
            </div>
            <Button
              variant="outline"
              className="w-full cursor-pointer"
              onClick={async () => {
                try {
                  const res = await fetch('/api/admin/reports?type=loans');
                  if (res.ok) {
                    const data = await res.json();
                    downloadJSON(data.loans, 'loans_report');
                  }
                } catch { /* silently fail */ }
              }}
            >
              <FileDown className="size-4 mr-2" />
              Export Loans
            </Button>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-6 flex flex-col items-center text-center gap-4">
            <div className="flex items-center justify-center size-14 rounded-xl bg-orange-50">
              <CreditCard className="size-7 text-orange-600" />
            </div>
            <div>
              <h3 className="font-semibold text-[#333333]">Payments Report</h3>
              <p className="text-sm text-gray-500 mt-1">Export all payment transactions</p>
            </div>
            <Button
              variant="outline"
              className="w-full cursor-pointer"
              onClick={async () => {
                try {
                  const res = await fetch('/api/admin/reports?type=payments');
                  if (res.ok) {
                    const data = await res.json();
                    downloadJSON(data.payments, 'payments_report');
                  }
                } catch { /* silently fail */ }
              }}
            >
              <FileDown className="size-4 mr-2" />
              Export Payments
            </Button>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-6 flex flex-col items-center text-center gap-4">
            <div className="flex items-center justify-center size-14 rounded-xl bg-purple-50">
              <ShieldCheck className="size-7 text-purple-600" />
            </div>
            <div>
              <h3 className="font-semibold text-[#333333]">KYC Report</h3>
              <p className="text-sm text-gray-500 mt-1">Export KYC verification records</p>
            </div>
            <Button
              variant="outline"
              className="w-full cursor-pointer"
              onClick={async () => {
                try {
                  const res = await fetch('/api/admin/kyc');
                  if (res.ok) {
                    const data = await res.json();
                    downloadJSON(data.records, 'kyc_report');
                  }
                } catch { /* silently fail */ }
              }}
            >
              <FileDown className="size-4 mr-2" />
              Export KYC
            </Button>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-6 flex flex-col items-center text-center gap-4">
            <div className="flex items-center justify-center size-14 rounded-xl bg-yellow-50">
              <Activity className="size-7 text-yellow-600" />
            </div>
            <div>
              <h3 className="font-semibold text-[#333333]">Activity Log</h3>
              <p className="text-sm text-gray-500 mt-1">Export system activity logs</p>
            </div>
            <Button
              variant="outline"
              className="w-full cursor-pointer"
              onClick={async () => {
                try {
                  const res = await fetch('/api/admin/reports?type=activity');
                  if (res.ok) {
                    const data = await res.json();
                    downloadJSON(data.logs, 'activity_report');
                  }
                } catch { /* silently fail */ }
              }}
            >
              <FileDown className="size-4 mr-2" />
              Export Activity
            </Button>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-6 flex flex-col items-center text-center gap-4">
            <div className="flex items-center justify-center size-14 rounded-xl bg-green-50">
              <BarChart3 className="size-7 text-green-600" />
            </div>
            <div>
              <h3 className="font-semibold text-[#333333]">Summary Report</h3>
              <p className="text-sm text-gray-500 mt-1">Export dashboard summary statistics</p>
            </div>
            <Button
              variant="outline"
              className="w-full cursor-pointer"
              onClick={async () => {
                try {
                  const res = await fetch('/api/admin/reports?type=summary');
                  if (res.ok) {
                    const data = await res.json();
                    downloadJSON(data, 'summary_report');
                  }
                } catch { /* silently fail */ }
              }}
            >
              <FileDown className="size-4 mr-2" />
              Export Summary
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  // --- Helper: Download JSON ---
  function downloadJSON(data: unknown, filename: string) {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filename}_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  // --- Section Router ---
  const renderSection = () => {
    switch (activeSection) {
      case 'overview':
        return renderOverview();
      case 'users':
        return renderUsers();
      case 'applications':
        return renderApplications();
      case 'kyc':
        return renderKyc();
      case 'payments':
        return renderPayments();
      case 'products':
        return renderProducts();
      case 'activity':
        return renderActivity();
      case 'notifications':
        return renderNotifications();
      case 'reports':
        return renderReports();
      default:
        return renderOverview();
    }
  };

  // --- Main Render ---
  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex shrink-0 border-r border-gray-200 bg-white">
        {renderSidebar()}
      </aside>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => setSidebarOpen(false)}
          />
          <aside className="absolute inset-y-0 left-0 w-64 bg-white shadow-xl">
            <div className="absolute right-3 top-4">
              <button
                onClick={() => setSidebarOpen(false)}
                className="flex h-8 w-8 items-center justify-center rounded-md text-gray-500 hover:bg-gray-100 cursor-pointer"
                aria-label="Close sidebar"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            {renderSidebar()}
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex flex-1 flex-col min-w-0">
        {/* Top Header */}
        <header className="sticky top-0 z-30 flex items-center justify-between border-b border-gray-200 bg-white px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <button
              className="flex h-9 w-9 items-center justify-center rounded-md text-gray-600 hover:bg-gray-100 lg:hidden cursor-pointer"
              onClick={() => setSidebarOpen(true)}
              aria-label="Open sidebar"
            >
              <Menu className="h-5 w-5" />
            </button>
            <div>
              <h1 className="text-lg font-semibold text-[#333333]">
                {NAV_ITEMS.find((item) => item.id === activeSection)?.label || 'Dashboard'}
              </h1>
              <p className="text-xs text-gray-500 hidden sm:block">
                MKOPA LOAN Admin Panel
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 text-sm text-gray-600">
              <Avatar className="size-7">
                <AvatarFallback className="bg-[#00A651] text-white text-xs">
                  {user?.fullName?.charAt(0)?.toUpperCase() || 'A'}
                </AvatarFallback>
              </Avatar>
              <span className="font-medium">{user?.fullName || 'Admin'}</span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="text-red-600 hover:text-red-700 hover:bg-red-50 cursor-pointer"
            >
              <LogOut className="size-4" />
            </Button>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-4 sm:p-6">
          {renderSection()}
        </main>
      </div>
    </div>
  );
}
