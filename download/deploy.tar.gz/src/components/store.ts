'use client';

import { create } from 'zustand';

export type View =
  | 'splash'
  | 'landing'
  | 'login'
  | 'register'
  | 'kyc'
  | 'loan-apply'
  | 'loan-confirmation'
  | 'loan-payment'
  | 'loan-success'
  | 'dashboard'
  | 'admin-dashboard';

interface User {
  id: string;
  fullName: string;
  phone: string;
  email: string;
  role: string;
  kycStatus?: string;
}

interface LoanApplication {
  id: string;
  loanAmount: number;
  processingFee: number;
  amountReceived: number;
  totalRepayment: number;
  repaymentDate: string;
  status: string;
  activationPaid: boolean;
  activationRef?: string;
  paymentRef?: string;
  createdAt: string;
}

interface Notification {
  id: string;
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
}

interface AppState {
  view: View;
  setView: (view: View) => void;
  user: User | null;
  setUser: (user: User | null) => void;
  loanApplication: LoanApplication | null;
  setLoanApplication: (app: LoanApplication | null) => void;
  notifications: Notification[];
  setNotifications: (n: Notification[]) => void;
  logout: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  view: 'splash',
  setView: (view) => set({ view }),
  user: null,
  setUser: (user) => set({ user }),
  loanApplication: null,
  setLoanApplication: (app) => set({ loanApplication: app }),
  notifications: [],
  setNotifications: (n) => set({ notifications: n }),
  logout: () => {
    set({ user: null, view: 'landing', loanApplication: null, notifications: [] });
    fetch('/api/auth/logout', { method: 'POST' });
  },
}));
