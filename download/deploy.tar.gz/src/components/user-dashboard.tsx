'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { useAppStore } from '@/components/store';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import Image from 'next/image';
import {
  Home,
  PlusCircle,
  Shield,
  Clock,
  Bell,
  Settings,
  LogOut,
  Menu,
  X,
  CheckCircle2,
  AlertCircle,
  Loader2,
  ChevronRight,
  User,
  Mail,
  Phone,
  Lock,
  DollarSign,
  FileText,
  Eye,
} from 'lucide-react';

// ─── Helper Functions ───────────────────────────────────────────────

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-KE', {
    style: 'currency',
    currency: 'KES',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

function getStatusColor(status: string): string {
  switch (status) {
    case 'approved':
      return 'bg-green-100 text-green-800';
    case 'submitted_for_review':
      return 'bg-blue-100 text-blue-800';
    case 'pending_activation':
      return 'bg-yellow-100 text-yellow-800';
    case 'rejected':
      return 'bg-red-100 text-red-800';
    case 'pending':
      return 'bg-yellow-100 text-yellow-800';
    case 'verified':
      return 'bg-green-100 text-green-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
}

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('en-KE', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

// ─── Types ──────────────────────────────────────────────────────────

interface LoanApplication {
  id: string;
  loanAmount: number;
  processingFee: number;
  amountReceived: number;
  totalRepayment: number;
  repaymentDate: string;
  status: string;
  activationPaid: boolean;
  activationRef?: string;
  paymentRef?: string;
  createdAt: string;
}

interface NotificationItem {
  id: string;
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
}

interface KycData {
  id: string;
  status: string;
  legalName: string;
  nationalId: string;
  verifiedAt?: string;
  rejectionReason?: string;
}

type DashboardView =
  | 'overview'
  | 'apply'
  | 'kyc'
  | 'history'
  | 'notifications'
  | 'settings';

interface NavItem {
  id: DashboardView;
  label: string;
  icon: React.ReactNode;
}

// ─── Navigation Items ───────────────────────────────────────────────

const navItems: NavItem[] = [
  { id: 'overview', label: 'Overview', icon: <Home className="h-5 w-5" /> },
  { id: 'apply', label: 'Apply for Loan', icon: <PlusCircle className="h-5 w-5" /> },
  { id: 'kyc', label: 'KYC Verification', icon: <Shield className="h-5 w-5" /> },
  { id: 'history', label: 'Loan History', icon: <Clock className="h-5 w-5" /> },
  { id: 'notifications', label: 'Notifications', icon: <Bell className="h-5 w-5" /> },
  { id: 'settings', label: 'Account Settings', icon: <Settings className="h-5 w-5" /> },
];

// ─── Component ──────────────────────────────────────────────────────

export default function UserDashboard() {
  const { user, logout, setView, setNotifications, notifications } = useAppStore();

  const [activeView, setActiveView] = useState<DashboardView>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const [loans, setLoans] = useState<LoanApplication[]>([]);
  const [kycData, setKycData] = useState<KycData | null>(null);
  const [kycStatus, setKycStatus] = useState<string>('not_submitted');
  const [loading, setLoading] = useState(true);
  const [notifs, setNotifs] = useState<NotificationItem[]>([]);

  // ─── Data Fetching ──────────────────────────────────────────────

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      // Fetch user profile with KYC status
      const meRes = await fetch('/api/auth/me');
      if (meRes.ok) {
        const meData = await meRes.json();
        if (meData.user?.kyc) {
          setKycStatus(meData.user.kyc.status);
          setKycData({
            id: '',
            status: meData.user.kyc.status,
            legalName: meData.user.kyc.legalName,
            nationalId: meData.user.kyc.nationalId,
            verifiedAt: meData.user.kyc.verifiedAt,
          });
        } else {
          setKycStatus('not_submitted');
        }
      }

      // Fetch loan applications
      const loansRes = await fetch('/api/loans/my-applications');
      if (loansRes.ok) {
        const loansData = await loansRes.json();
        setLoans(loansData.applications || []);
      }

      // Fetch notifications
      const notifRes = await fetch('/api/notifications');
      if (notifRes.ok) {
        const notifData = await notifRes.json();
        setNotifs(notifData.notifications || []);
        setNotifications(notifData.notifications || []);
      }
    } catch {
      // Silently handle fetch errors
    } finally {
      setLoading(false);
    }
  }, [setNotifications]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // ─── Mark Notification Read ─────────────────────────────────────

  const markAsRead = async (notificationId: string) => {
    try {
      const res = await fetch('/api/notifications', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notificationId }),
      });
      if (res.ok) {
        setNotifs((prev) =>
          prev.map((n) => (n.id === notificationId ? { ...n, read: true } : n))
        );
      }
    } catch {
      // Silently handle
    }
  };

  // ─── Derived Data ───────────────────────────────────────────────

  const unreadCount = notifs.filter((n) => !n.read).length;
  const activeLoans = loans.filter(
    (l) => l.status === 'approved' || l.status === 'submitted_for_review'
  );
  const latestApplication = loans[0] || null;
  const isKycVerified = kycStatus === 'verified';

  // ─── Handle Navigation ──────────────────────────────────────────

  const handleNavClick = (view: DashboardView) => {
    setActiveView(view);
    setSidebarOpen(false);
  };

  const handleLogout = () => {
    logout();
    setView('landing');
  };

  // ─── Sidebar Content ────────────────────────────────────────────

  const sidebarContent = (
    <div className="flex h-full flex-col">
      {/* Brand */}
      <div className="flex items-center gap-3 border-b border-gray-200 px-4 py-5">
        <Image src="/logo.png" alt="MKOPA LOAN" width={36} height={36} className="rounded-lg" />
        <div>
          <h2 className="text-base font-bold text-[#333333]">MKOPA LOAN</h2>
          <p className="text-xs text-gray-500">Digital Lending</p>
        </div>
      </div>

      {/* Nav Items */}
      <nav className="flex-1 px-3 py-4">
        <ul className="space-y-1">
          {navItems.map((item) => (
            <li key={item.id}>
              <button
                onClick={() => handleNavClick(item.id)}
                className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                  activeView === item.id
                    ? 'bg-[#00A651]/10 text-[#00A651]'
                    : 'text-gray-600 hover:bg-gray-100 hover:text-[#333333]'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
                {item.id === 'notifications' && unreadCount > 0 && (
                  <span className="ml-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-red-500 px-1.5 text-[10px] font-bold text-white">
                    {unreadCount}
                  </span>
                )}
              </button>
            </li>
          ))}
        </ul>
      </nav>

      <Separator />

      {/* User Info & Logout */}
      <div className="px-3 py-4">
        <div className="flex items-center gap-3 rounded-lg px-3 py-2">
          <Avatar className="h-9 w-9">
            <AvatarFallback className="bg-[#00A651] text-sm font-semibold text-white">
              {user?.fullName?.charAt(0)?.toUpperCase() || 'U'}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-[#333333]">
              {user?.fullName || 'User'}
            </p>
            <p className="truncate text-xs text-gray-500">{user?.email || ''}</p>
          </div>
        </div>
        <button
          onClick={handleLogout}
          className="mt-2 flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-red-600 transition-colors hover:bg-red-50"
        >
          <LogOut className="h-5 w-5" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );

  // ─── Overview Section ───────────────────────────────────────────

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Welcome Message */}
      <div>
        <h2 className="text-2xl font-bold text-[#333333]">
          Welcome back, {user?.fullName?.split(' ')[0] || 'User'}!
        </h2>
        <p className="mt-1 text-sm text-gray-500">
          Here&apos;s an overview of your account and loan activity.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Account Status */}
        <Card className="border-l-4 border-l-[#00A651]">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
                  Account Status
                </p>
                <p className="mt-1 text-lg font-semibold text-[#333333]">
                  Active
                </p>
              </div>
              <Badge className="bg-green-100 text-green-800">Active</Badge>
            </div>
          </CardContent>
        </Card>

        {/* Loan Application Status */}
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
                  Loan Status
                </p>
                <p className="mt-1 text-lg font-semibold text-[#333333]">
                  {latestApplication
                    ? latestApplication.status.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())
                    : 'No Application'}
                </p>
              </div>
              {latestApplication && (
                <Badge className={getStatusColor(latestApplication.status)}>
                  {latestApplication.status.replace(/_/g, ' ')}
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Activation Fee Status */}
        <Card className="border-l-4 border-l-yellow-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
                  Activation Fee
                </p>
                <p className="mt-1 text-lg font-semibold text-[#333333]">
                  {latestApplication
                    ? latestApplication.activationPaid
                      ? 'Paid'
                      : 'Pending'
                    : 'N/A'}
                </p>
              </div>
              {latestApplication && (
                <Badge
                  className={
                    latestApplication.activationPaid
                      ? 'bg-green-100 text-green-800'
                      : 'bg-yellow-100 text-yellow-800'
                  }
                >
                  {latestApplication.activationPaid ? 'Paid' : 'Pending'}
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Available Loan Limit */}
        <Card className="border-l-4 border-l-[#00A651]">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
                  Available Limit
                </p>
                <p className="mt-1 text-lg font-semibold text-[#333333]">
                  {isKycVerified ? formatCurrency(500000) : formatCurrency(0)}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-[#00A651]" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active Loans */}
      {activeLoans.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-semibold text-[#333333]">
              <FileText className="h-5 w-5 text-[#00A651]" />
              Active Loans
            </CardTitle>
          </CardHeader>
          <CardContent className="px-4 pb-4">
            <div className="overflow-x-auto rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Repayment Date</TableHead>
                    <TableHead className="text-right">Outstanding</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {activeLoans.map((loan) => (
                    <TableRow key={loan.id}>
                      <TableCell className="font-medium">
                        {formatCurrency(loan.loanAmount)}
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(loan.status)}>
                          {loan.status.replace(/_/g, ' ')}
                        </Badge>
                      </TableCell>
                      <TableCell>{formatDate(loan.repaymentDate)}</TableCell>
                      <TableCell className="text-right font-medium">
                        {formatCurrency(loan.totalRepayment)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Notifications */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-base font-semibold text-[#333333]">
              <Bell className="h-5 w-5 text-[#00A651]" />
              Recent Notifications
            </CardTitle>
            {notifs.length > 3 && (
              <Button
                variant="ghost"
                size="sm"
                className="text-xs text-[#00A651] hover:text-[#008f45]"
                onClick={() => setActiveView('notifications')}
              >
                View All
                <ChevronRight className="ml-1 h-3 w-3" />
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          {notifs.length === 0 ? (
            <p className="py-4 text-center text-sm text-gray-400">
              No notifications yet
            </p>
          ) : (
            <div className="space-y-3">
              {notifs.slice(0, 3).map((notif) => (
                <div
                  key={notif.id}
                  className={`flex items-start gap-3 rounded-lg border p-3 transition-colors cursor-pointer ${
                    notif.read
                      ? 'border-gray-100 bg-white'
                      : 'border-[#00A651]/20 bg-[#00A651]/5'
                  }`}
                  onClick={() => !notif.read && markAsRead(notif.id)}
                >
                  <div
                    className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${
                      notif.read ? 'bg-gray-100' : 'bg-[#00A651]/10'
                    }`}
                  >
                    <Bell
                      className={`h-4 w-4 ${
                        notif.read ? 'text-gray-400' : 'text-[#00A651]'
                      }`}
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p
                      className={`text-sm ${
                        notif.read
                          ? 'font-normal text-gray-600'
                          : 'font-semibold text-[#333333]'
                      }`}
                    >
                      {notif.title}
                    </p>
                    <p className="mt-0.5 text-xs text-gray-500 line-clamp-2">
                      {notif.message}
                    </p>
                    <p className="mt-1 text-[10px] text-gray-400">
                      {formatDate(notif.createdAt)}
                    </p>
                  </div>
                  {!notif.read && (
                    <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-[#00A651]" />
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );

  // ─── Apply for Loan Section ─────────────────────────────────────

  const renderApply = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-[#333333]">Apply for Loan</h2>
        <p className="mt-1 text-sm text-gray-500">
          Start your loan application process
        </p>
      </div>

      {!isKycVerified ? (
        <Card className="border-yellow-200 bg-yellow-50">
          <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-yellow-100">
              <Shield className="h-8 w-8 text-yellow-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-[#333333]">
                Complete KYC Verification First
              </h3>
              <p className="mt-2 max-w-md text-sm text-gray-600">
                You need to complete your KYC verification before you can apply
                for a loan. This helps us verify your identity and protect your
                account.
              </p>
            </div>
            <Button
              className="bg-[#00A651] text-white hover:bg-[#008f45]"
              size="lg"
              onClick={() => setActiveView('kyc')}
            >
              <Shield className="mr-2 h-4 w-4" />
              Complete KYC
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
              <CheckCircle2 className="h-8 w-8 text-[#00A651]" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-[#333333]">
                You&apos;re Eligible to Apply!
              </h3>
              <p className="mt-2 max-w-md text-sm text-gray-600">
                Your KYC verification is complete. You can now apply for a loan
                up to {formatCurrency(500000)}.
              </p>
            </div>
            <Button
              className="bg-[#00A651] text-white hover:bg-[#008f45]"
              size="lg"
              onClick={() => setView('loan-apply')}
            >
              <PlusCircle className="mr-2 h-4 w-4" />
              Apply Now
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );

  // ─── KYC Verification Section ───────────────────────────────────

  const renderKyc = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-[#333333]">KYC Verification</h2>
        <p className="mt-1 text-sm text-gray-500">
          Manage your identity verification status
        </p>
      </div>

      {kycStatus === 'not_submitted' && (
        <Card className="border-gray-200">
          <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gray-100">
              <AlertCircle className="h-8 w-8 text-gray-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-[#333333]">
                KYC Not Submitted
              </h3>
              <p className="mt-2 max-w-md text-sm text-gray-600">
                You haven&apos;t submitted your KYC documents yet. Complete your
                verification to unlock loan applications.
              </p>
            </div>
            <Button
              className="bg-[#00A651] text-white hover:bg-[#008f45]"
              size="lg"
              onClick={() => setView('kyc')}
            >
              <Shield className="mr-2 h-4 w-4" />
              Complete KYC
            </Button>
          </CardContent>
        </Card>
      )}

      {kycStatus === 'pending' && (
        <Card className="border-yellow-200 bg-yellow-50">
          <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-yellow-100">
              <Loader2 className="h-8 w-8 animate-spin text-yellow-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-[#333333]">
                Verification In Progress
              </h3>
              <p className="mt-2 max-w-md text-sm text-gray-600">
                Your KYC documents have been submitted and are currently being
                reviewed. You will be notified once the verification is complete.
              </p>
            </div>
            <Badge className="bg-yellow-100 text-yellow-800 px-4 py-1 text-sm">
              <Clock className="mr-1 h-3 w-3" />
              Pending Review
            </Badge>
          </CardContent>
        </Card>
      )}

      {kycStatus === 'verified' && (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
              <CheckCircle2 className="h-8 w-8 text-[#00A651]" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-[#333333]">
                KYC Verified
              </h3>
              <p className="mt-2 max-w-md text-sm text-gray-600">
                Your identity has been successfully verified. You are eligible to
                apply for loans.
                {kycData?.verifiedAt && (
                  <span className="block mt-1 text-xs text-gray-400">
                    Verified on {formatDate(kycData.verifiedAt)}
                  </span>
                )}
              </p>
            </div>
            <Badge className="bg-green-100 text-green-800 px-4 py-1 text-sm">
              <CheckCircle2 className="mr-1 h-3 w-3" />
              Verified
            </Badge>
          </CardContent>
        </Card>
      )}

      {kycStatus === 'rejected' && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-red-100">
              <X className="h-8 w-8 text-red-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-[#333333]">
                KYC Verification Rejected
              </h3>
              <p className="mt-2 max-w-md text-sm text-gray-600">
                Your KYC verification was not approved. Please review the reason
                below and resubmit your documents.
              </p>
              {kycData?.rejectionReason && (
                <div className="mt-3 rounded-lg border border-red-200 bg-white p-3 text-sm text-red-700">
                  <strong>Reason:</strong> {kycData.rejectionReason}
                </div>
              )}
            </div>
            <Button
              className="bg-[#00A651] text-white hover:bg-[#008f45]"
              size="lg"
              onClick={() => setView('kyc')}
            >
              <Shield className="mr-2 h-4 w-4" />
              Resubmit KYC
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );

  // ─── Loan History Section ───────────────────────────────────────

  const renderHistory = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-[#333333]">Loan History</h2>
        <p className="mt-1 text-sm text-gray-500">
          View all your loan applications
        </p>
      </div>

      {loans.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gray-100">
              <FileText className="h-8 w-8 text-gray-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-[#333333]">
                No Loan History
              </h3>
              <p className="mt-2 text-sm text-gray-600">
                You haven&apos;t applied for any loans yet.
              </p>
            </div>
            <Button
              className="bg-[#00A651] text-white hover:bg-[#008f45]"
              onClick={() => setActiveView('apply')}
            >
              <PlusCircle className="mr-2 h-4 w-4" />
              Apply for a Loan
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead>Date</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Processing Fee</TableHead>
                    <TableHead>Net Amount</TableHead>
                    <TableHead>Repayment</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Repayment Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loans.map((loan) => (
                    <TableRow key={loan.id}>
                      <TableCell className="text-xs">
                        {formatDate(loan.createdAt)}
                      </TableCell>
                      <TableCell className="font-medium">
                        {formatCurrency(loan.loanAmount)}
                      </TableCell>
                      <TableCell className="text-red-600">
                        {formatCurrency(loan.processingFee)}
                      </TableCell>
                      <TableCell className="font-medium text-[#00A651]">
                        {formatCurrency(loan.amountReceived)}
                      </TableCell>
                      <TableCell>
                        {formatCurrency(loan.totalRepayment)}
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(loan.status)}>
                          {loan.status.replace(/_/g, ' ')}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-xs">
                        {formatDate(loan.repaymentDate)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );

  // ─── Notifications Section ──────────────────────────────────────

  const renderNotifications = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-[#333333]">Notifications</h2>
          <p className="mt-1 text-sm text-gray-500">
            {unreadCount > 0
              ? `You have ${unreadCount} unread notification${unreadCount > 1 ? 's' : ''}`
              : 'All caught up!'}
          </p>
        </div>
        {unreadCount > 0 && (
          <Button
            variant="outline"
            size="sm"
            className="text-[#00A651] border-[#00A651] hover:bg-[#00A651]/10"
            onClick={async () => {
              for (const n of notifs.filter((nf) => !nf.read)) {
                await markAsRead(n.id);
              }
            }}
          >
            <Eye className="mr-1 h-3 w-3" />
            Mark All Read
          </Button>
        )}
      </div>

      {notifs.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gray-100">
              <Bell className="h-8 w-8 text-gray-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-[#333333]">
                No Notifications
              </h3>
              <p className="mt-2 text-sm text-gray-600">
                You don&apos;t have any notifications at the moment.
              </p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {notifs.map((notif) => (
            <Card
              key={notif.id}
              className={`cursor-pointer transition-colors ${
                notif.read
                  ? 'border-gray-200'
                  : 'border-[#00A651]/30 bg-[#00A651]/5'
              }`}
              onClick={() => !notif.read && markAsRead(notif.id)}
            >
              <CardContent className="flex items-start gap-4 p-4">
                <div
                  className={`mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${
                    notif.read ? 'bg-gray-100' : 'bg-[#00A651]/10'
                  }`}
                >
                  <Bell
                    className={`h-5 w-5 ${
                      notif.read ? 'text-gray-400' : 'text-[#00A651]'
                    }`}
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <h4
                      className={`text-sm ${
                        notif.read
                          ? 'font-normal text-gray-700'
                          : 'font-semibold text-[#333333]'
                      }`}
                    >
                      {notif.title}
                    </h4>
                    {!notif.read && (
                      <span className="h-2 w-2 shrink-0 rounded-full bg-[#00A651]" />
                    )}
                  </div>
                  <p className="mt-1 text-sm text-gray-500">{notif.message}</p>
                  <p className="mt-2 text-xs text-gray-400">
                    {formatDate(notif.createdAt)}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );

  // ─── Account Settings Section ───────────────────────────────────

  const renderSettings = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-[#333333]">Account Settings</h2>
        <p className="mt-1 text-sm text-gray-500">
          Manage your account information
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base font-semibold text-[#333333]">
            Personal Information
          </CardTitle>
          <CardDescription>
            Your account details
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16">
              <AvatarFallback className="bg-[#00A651] text-xl font-bold text-white">
                {user?.fullName?.charAt(0)?.toUpperCase() || 'U'}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="text-lg font-semibold text-[#333333]">
                {user?.fullName || 'User'}
              </p>
              <p className="text-sm text-gray-500">
                Member since {user?.id ? '2024' : 'N/A'}
              </p>
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <div className="flex items-start gap-3 rounded-lg border p-3">
              <User className="mt-0.5 h-5 w-5 shrink-0 text-[#00A651]" />
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
                  Full Name
                </p>
                <p className="mt-0.5 text-sm font-medium text-[#333333]">
                  {user?.fullName || 'Not provided'}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-lg border p-3">
              <Mail className="mt-0.5 h-5 w-5 shrink-0 text-[#00A651]" />
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
                  Email Address
                </p>
                <p className="mt-0.5 text-sm font-medium text-[#333333]">
                  {user?.email || 'Not provided'}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-lg border p-3">
              <Phone className="mt-0.5 h-5 w-5 shrink-0 text-[#00A651]" />
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
                  Phone Number
                </p>
                <p className="mt-0.5 text-sm font-medium text-[#333333]">
                  {user?.phone || 'Not provided'}
                </p>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h3 className="text-sm font-semibold text-[#333333]">
              Change Password
            </h3>
            <p className="mt-1 text-xs text-gray-500">
              Password change functionality will be available soon.
            </p>
            <Button
              variant="outline"
              className="mt-3 text-gray-400"
              disabled
            >
              <Lock className="mr-2 h-4 w-4" />
              Change Password (Coming Soon)
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  // ─── View Renderer ──────────────────────────────────────────────

  const renderView = () => {
    switch (activeView) {
      case 'overview':
        return renderOverview();
      case 'apply':
        return renderApply();
      case 'kyc':
        return renderKyc();
      case 'history':
        return renderHistory();
      case 'notifications':
        return renderNotifications();
      case 'settings':
        return renderSettings();
      default:
        return renderOverview();
    }
  };

  // ─── Main Render ────────────────────────────────────────────────

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-50">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="h-10 w-10 animate-spin text-[#00A651]" />
          <p className="text-sm font-medium text-gray-500">
            Loading dashboard...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Desktop Sidebar */}
      <aside className="hidden w-64 shrink-0 border-r border-gray-200 bg-white lg:block">
        <ScrollArea className="h-screen">{sidebarContent}</ScrollArea>
      </aside>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => setSidebarOpen(false)}
          />
          <aside className="absolute inset-y-0 left-0 w-64 bg-white shadow-xl">
            <div className="absolute right-3 top-4">
              <button
                onClick={() => setSidebarOpen(false)}
                className="flex h-8 w-8 items-center justify-center rounded-md text-gray-500 hover:bg-gray-100"
                aria-label="Close sidebar"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            {sidebarContent}
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex flex-1 flex-col min-w-0">
        {/* Top Header */}
        <header className="sticky top-0 z-30 flex items-center justify-between border-b border-gray-200 bg-white px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <button
              className="flex h-9 w-9 items-center justify-center rounded-md text-gray-600 hover:bg-gray-100 lg:hidden"
              onClick={() => setSidebarOpen(true)}
              aria-label="Open sidebar"
            >
              <Menu className="h-5 w-5" />
            </button>
            <div>
              <h1 className="text-lg font-semibold text-[#333333]">
                {navItems.find((item) => item.id === activeView)?.label || 'Dashboard'}
              </h1>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              className="relative flex h-9 w-9 items-center justify-center rounded-full text-gray-600 hover:bg-gray-100 transition-colors"
              onClick={() => setActiveView('notifications')}
              aria-label="View notifications"
            >
              <Bell className="h-5 w-5" />
              {unreadCount > 0 && (
                <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 text-[9px] font-bold text-white">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </button>
            <div className="hidden items-center gap-2 sm:flex">
              <Avatar className="h-8 w-8">
                <AvatarFallback className="bg-[#00A651] text-xs font-semibold text-white">
                  {user?.fullName?.charAt(0)?.toUpperCase() || 'U'}
                </AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium text-[#333333]">
                {user?.fullName?.split(' ')[0] || 'User'}
              </span>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6">
          {renderView()}
        </main>
      </div>
    </div>
  );
}
