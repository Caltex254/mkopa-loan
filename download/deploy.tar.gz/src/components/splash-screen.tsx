'use client';

import { useEffect, useState } from 'react';
import Image from 'next/image';

interface SplashScreenProps {
  onFinished: () => void;
  minDuration?: number; // in milliseconds
}

export default function SplashScreen({ onFinished, minDuration = 3000 }: SplashScreenProps) {
  const [fadeOut, setFadeOut] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const startTime = Date.now();
    const progressInterval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min((elapsed / minDuration) * 100, 100);
      setProgress(pct);
    }, 30);

    const timer = setTimeout(() => {
      clearInterval(progressInterval);
      setProgress(100);
      setFadeOut(true);
      setTimeout(onFinished, 600);
    }, minDuration);

    return () => {
      clearTimeout(timer);
      clearInterval(progressInterval);
    };
  }, [minDuration, onFinished]);

  return (
    <div
      className={`fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-gradient-to-br from-[#00A651] via-[#008f45] to-[#006b34] transition-opacity duration-600 ${
        fadeOut ? 'opacity-0' : 'opacity-100'
      }`}
    >
      {/* Decorative background elements */}
      <div className="pointer-events-none absolute -right-20 -top-20 size-80 rounded-full bg-white/5" />
      <div className="pointer-events-none absolute -bottom-32 -left-32 size-96 rounded-full bg-white/5" />
      <div className="pointer-events-none absolute left-1/4 top-1/3 size-48 rounded-full bg-white/5" />
      <div className="pointer-events-none absolute bottom-1/4 right-1/3 size-64 rounded-full bg-white/3" />

      {/* Logo Container */}
      <div className="relative flex flex-col items-center">
        {/* Animated glow ring */}
        <div className="absolute -inset-6 rounded-full bg-white/10 animate-pulse" />

        {/* Logo */}
        <div className="relative z-10 mb-6 flex items-center justify-center">
          <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-full bg-white/15 backdrop-blur-sm border-2 border-white/20 flex items-center justify-center shadow-2xl p-3 sm:p-4">
            <Image
              src="/logo.png"
              alt="MKOPA LOAN Logo"
              width={100}
              height={100}
              className="w-full h-full object-contain drop-shadow-lg"
              priority
            />
          </div>
        </div>

        {/* Brand Name */}
        <h1 className="relative z-10 text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
          MKOPA <span className="text-yellow-300">LOAN</span>
        </h1>

        {/* Tagline */}
        <p className="relative z-10 mt-3 text-sm sm:text-base text-white/80 font-medium">
          Instant Digital Loans
        </p>

        {/* Loading Indicator */}
        <div className="relative z-10 mt-10 w-48 sm:w-56">
          <div className="h-1.5 w-full rounded-full bg-white/20 overflow-hidden">
            <div
              className="h-full rounded-full bg-yellow-300 transition-all duration-100 ease-linear"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="mt-3 text-center text-xs text-white/60 font-medium">
            {progress < 30
              ? 'Initializing...'
              : progress < 60
              ? 'Loading resources...'
              : progress < 90
              ? 'Almost ready...'
              : 'Welcome!'}
          </p>
        </div>
      </div>

      {/* Bottom text */}
      <div className="absolute bottom-8 text-center">
        <p className="text-xs text-white/40">
          &copy; {new Date().getFullYear()} MKOPA LOAN. All rights reserved.
        </p>
      </div>
    </div>
  );
}
