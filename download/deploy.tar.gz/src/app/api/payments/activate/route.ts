import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest } from '@/lib/auth';
import { ACTIVATION_FEE } from '@/lib/loans';

const PAYMENT_API_KEY = process.env.PAYMENT_API_KEY || 'pg_Q4LRdgtUxO3HWEYFuOUxvLf2cNDZYHtz';
const PAYMENT_BASE_URL = process.env.PAYMENT_BASE_URL || 'https://pay.xdigitex.space/api';
const APP_URL = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';

// Determine gateway from phone number prefix
function detectGateway(phone: string): 'safaricom' | 'airtel' | 'mobile' {
  const cleaned = phone.replace(/\+/g, '').replace(/\s/g, '');
  // Kenya numbers: +254
  if (cleaned.startsWith('254')) {
    const prefix = cleaned.substring(3, 6);
    // Safaricom prefixes: 700-729, 740-749, 768-769, 790-799, 110-113
    const safaricomPrefixes = ['700','701','702','703','704','705','706','707','708','709','710','711','712','713','714','715','716','717','718','719','720','721','722','723','724','725','726','727','728','729','740','741','742','743','744','745','746','747','748','749','768','769','790','791','792','793','794','795','796','797','798','799','110','111','112','113'];
    if (safaricomPrefixes.includes(prefix)) {
      return 'safaricom';
    }
    // Airtel prefixes: 730-739, 750-759, 780-789
    const airtelPrefixes = ['730','731','732','733','734','735','736','737','738','739','750','751','752','753','754','755','756','757','758','759','780','781','782','783','784','785','786','787','788','789'];
    if (airtelPrefixes.includes(prefix)) {
      return 'airtel';
    }
  }
  // Default to mobile (pan-Africa auto-detect)
  return 'mobile';
}

// Format phone number to international format
function formatPhone(phone: string): string {
  let cleaned = phone.replace(/\s/g, '');
  if (cleaned.startsWith('0')) {
    cleaned = '+254' + cleaned.substring(1);
  } else if (cleaned.startsWith('7') || cleaned.startsWith('1')) {
    cleaned = '+254' + cleaned;
  } else if (!cleaned.startsWith('+')) {
    cleaned = '+' + cleaned;
  }
  return cleaned;
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromRequest();
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { applicationId, phoneNumber, gateway: preferredGateway } = body;

    if (!applicationId || !phoneNumber) {
      return NextResponse.json(
        { error: 'Application ID and phone number are required' },
        { status: 400 }
      );
    }

    // Find the loan application
    const application = await db.loanApplication.findUnique({
      where: { id: applicationId },
    });

    if (!application) {
      return NextResponse.json(
        { error: 'Loan application not found' },
        { status: 404 }
      );
    }

    // Verify the application belongs to the authenticated user
    if (application.userId !== user.userId) {
      return NextResponse.json(
        { error: 'This application does not belong to you' },
        { status: 403 }
      );
    }

    // Check that application status is "pending_activation"
    if (application.status !== 'pending_activation') {
      return NextResponse.json(
        { error: `Application status must be 'pending_activation', current status is '${application.status}'` },
        { status: 400 }
      );
    }

    // Check if already paid
    if (application.activationPaid) {
      return NextResponse.json(
        { error: 'Activation fee already paid for this application' },
        { status: 400 }
      );
    }

    const formattedPhone = formatPhone(phoneNumber);
    const gateway = preferredGateway || detectGateway(formattedPhone);
    const activationAmount = ACTIVATION_FEE;

    // Create a pending payment record first
    const transactionId = `TXN-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const paymentRef = `REF-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;

    const payment = await db.payment.create({
      data: {
        userId: user.userId,
        applicationId: application.id,
        transactionId,
        paymentRef,
        phoneNumber: formattedPhone,
        amount: activationAmount,
        status: 'pending',
        type: 'activation',
      },
    });

    // Call the Xdigitex Pay API to initiate STK Push
    try {
      const paymentPayload: Record<string, unknown> = {
        amount: activationAmount,
        currency: 'KES',
        gateway: gateway,
        phone: formattedPhone,
        email: user.userId, // fallback since we don't store email in token
        first_name: 'MKOPA',
        last_name: 'LOAN',
        description: `Activation Fee - Loan Application ${applicationId}`,
        callback_url: `${APP_URL}/api/payments/callback`,
        webhook_url: `${APP_URL}/api/payments/webhook`,
      };

      const xdigitexResponse = await fetch(`${PAYMENT_BASE_URL}/payments/initiate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-API-Key': PAYMENT_API_KEY,
        },
        body: JSON.stringify(paymentPayload),
      });

      const xdigitexData = await xdigitexResponse.json();

      if (!xdigitexResponse.ok || !xdigitexData.success) {
        console.error('Xdigitex payment initiation failed:', xdigitexData);

        // Update payment status to failed
        await db.payment.update({
          where: { id: payment.id },
          data: { status: 'failed' },
        });

        return NextResponse.json(
          {
            error: xdigitexData.message || 'Payment initiation failed. Please try again.',
            details: xdigitexData,
          },
          { status: 400 }
        );
      }

      // Update payment with Xdigitex reference
      await db.payment.update({
        where: { id: payment.id },
        data: {
          transactionId: xdigitexData.reference || transactionId,
          status: 'processing',
        },
      });

      // For Safaricom/Airtel STK Push, the customer receives a prompt on their phone
      // We need to poll for the status or wait for webhook
      const isStkPush = gateway === 'safaricom' || gateway === 'airtel' || gateway === 'mobile';

      return NextResponse.json({
        success: true,
        message: isStkPush
          ? 'STK Push sent! Please check your phone and enter your PIN to complete payment.'
          : 'Payment initiated successfully.',
        payment: {
          id: payment.id,
          transactionId: xdigitexData.reference || transactionId,
          paymentRef,
          amount: activationAmount,
          status: 'processing',
          type: 'activation',
          gateway: gateway,
          reference: xdigitexData.reference,
          createdAt: payment.createdAt,
        },
        xdigitex: {
          reference: xdigitexData.reference,
          gateway: xdigitexData.gateway,
          message: xdigitexData.message,
          redirect_url: xdigitexData.redirect_url,
        },
      }, { status: 200 });

    } catch (fetchError) {
      console.error('Failed to reach Xdigitex Pay API:', fetchError);

      // Update payment status to failed
      await db.payment.update({
        where: { id: payment.id },
        data: { status: 'failed' },
      });

      return NextResponse.json(
        { error: 'Payment service unavailable. Please try again later.' },
        { status: 503 }
      );
    }
  } catch (error) {
    console.error('Activation payment error:', error);
    return NextResponse.json(
      { error: 'Failed to process activation payment' },
      { status: 500 }
    );
  }
}
