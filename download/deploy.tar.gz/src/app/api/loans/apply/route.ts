import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest } from '@/lib/auth';
import { calculateLoan } from '@/lib/loans';

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromRequest();
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { loanAmount } = body;

    if (!loanAmount) {
      return NextResponse.json({ error: 'loanAmount is required' }, { status: 400 });
    }

    // Verify user has completed KYC with status "verified"
    const kyc = await db.kYC.findUnique({
      where: { userId: user.userId },
    });

    if (!kyc || kyc.status !== 'verified') {
      return NextResponse.json(
        { error: 'KYC verification must be completed before applying for a loan' },
        { status: 400 }
      );
    }

    // Calculate loan details
    const loanDetails = calculateLoan(Number(loanAmount));
    if (!loanDetails) {
      return NextResponse.json(
        { error: 'Invalid loan amount. Please select a valid loan product.' },
        { status: 400 }
      );
    }

    // Create loan application
    const application = await db.loanApplication.create({
      data: {
        userId: user.userId,
        loanAmount: loanDetails.loanAmount,
        processingFee: loanDetails.processingFee,
        amountReceived: loanDetails.amountReceived,
        totalRepayment: loanDetails.totalRepayment,
        repaymentDate: loanDetails.repaymentDate,
        status: 'pending_activation',
      },
    });

    // Create activity log entry
    await db.activityLog.create({
      data: {
        userId: user.userId,
        action: 'LOAN_APPLICATION_CREATED',
        details: `Loan application submitted for KES ${loanDetails.loanAmount}`,
      },
    });

    return NextResponse.json({ application }, { status: 201 });
  } catch (error) {
    console.error('Loan application error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
