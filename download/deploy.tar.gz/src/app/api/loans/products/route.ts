import { NextResponse } from 'next/server';
import { LOAN_PRODUCTS } from '@/lib/loans';

export async function GET() {
  return NextResponse.json({ products: LOAN_PRODUCTS });
}
