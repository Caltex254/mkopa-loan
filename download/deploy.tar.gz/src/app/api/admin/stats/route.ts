import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest } from '@/lib/auth';

export async function GET() {
  try {
    const user = await getUserFromRequest();
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (user.role !== 'admin') {
      return NextResponse.json(
        { error: 'Forbidden: Admin access required' },
        { status: 403 }
      );
    }

    // Run all count queries in parallel
    const [
      totalUsers,
      totalApplications,
      pendingKYC,
      pendingReview,
      approvedLoans,
      rejectedLoans,
      approvedLoanData,
    ] = await Promise.all([
      db.user.count(),
      db.loanApplication.count(),
      db.kYC.count({ where: { status: 'pending' } }),
      db.loanApplication.count({ where: { status: 'submitted_for_review' } }),
      db.loanApplication.count({ where: { status: 'approved' } }),
      db.loanApplication.count({ where: { status: 'rejected' } }),
      db.loanApplication.findMany({
        where: { status: 'approved' },
        select: { loanAmount: true },
      }),
    ]);

    // Calculate total disbursed amount
    const totalDisbursed = approvedLoanData.reduce(
      (sum, app) => sum + app.loanAmount,
      0
    );

    return NextResponse.json({
      totalUsers,
      totalApplications,
      pendingKYC,
      pendingReview,
      approvedLoans,
      rejectedLoans,
      totalDisbursed,
    }, { status: 200 });
  } catch (error) {
    console.error('Admin stats error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch admin stats' },
      { status: 500 }
    );
  }
}
