'use client';

import { useCallback, useEffect } from 'react';
import { useAppStore } from '@/components/store';
import SplashScreen from '@/components/splash-screen';
import Landing from '@/components/landing';
import Login from '@/components/auth/login';
import Register from '@/components/auth/register';
import KYC from '@/components/kyc';
import LoanApplication from '@/components/loan-application';
import LoanSuccess from '@/components/loan-success';
import UserDashboard from '@/components/user-dashboard';
import AdminDashboard from '@/components/admin-dashboard';

export default function Home() {
  const { view, setUser, setView } = useAppStore();

  // Check for existing auth on mount
  useEffect(() => {
    async function checkAuth() {
      try {
        const res = await fetch('/api/auth/me');
        if (res.ok) {
          const data = await res.json();
          if (data.user) {
            setUser(data.user);
          }
        }
      } catch {
        // Not authenticated, stay on landing
      }
    }
    checkAuth();
  }, [setUser]);

  const handleSplashFinished = useCallback(() => {
    const { user } = useAppStore.getState();
    if (user?.role === 'admin') {
      setView('admin-dashboard');
    } else if (user) {
      setView('dashboard');
    } else {
      setView('landing');
    }
  }, [setView]);

  return (
    <main className="min-h-screen">
      {view === 'splash' && <SplashScreen onFinished={handleSplashFinished} minDuration={3000} />}
      {view === 'landing' && <Landing />}
      {view === 'login' && <Login />}
      {view === 'register' && <Register />}
      {view === 'kyc' && <KYC />}
      {view === 'loan-apply' && <LoanApplication />}
      {view === 'loan-success' && <LoanSuccess />}
      {view === 'dashboard' && <UserDashboard />}
      {view === 'admin-dashboard' && <AdminDashboard />}
    </main>
  );
}
