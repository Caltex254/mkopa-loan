#!/bin/bash
# MKOPA LOAN - Start script with Cloudflare Tunnel
# This script starts the Next.js application and the Cloudflare tunnel

set -e

echo "=== MKOPA LOAN - Starting Application ==="

# Start the Next.js application
echo "Starting Next.js application..."
cd /home/z/my-project

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
  echo "Installing dependencies..."
  bun install
fi

# Generate Prisma client
echo "Generating Prisma client..."
bun run db:generate

# Push database schema
echo "Pushing database schema..."
bun run db:push

# Build the application
echo "Building application..."
bun run build

# Start the production server in the background
echo "Starting production server..."
bun run start &
NEXT_PID=$!

# Wait for server to be ready
echo "Waiting for server to start..."
for i in $(seq 1 30); do
  if curl -s http://localhost:3000 > /dev/null 2>&1; then
    echo "Server is ready!"
    break
  fi
  sleep 1
done

# Start Cloudflare tunnel
echo "Starting Cloudflare tunnel..."
cloudflared tunnel run --token eyJhIjoiZDcwNTRjYzg3MjUxNTU2MzA1MDNlYzdkOTZjNmFjZmIiLCJ0IjoiODlhZDNkY2UtMTVjMS00MDlkLWExNjYtZWM5NmY4MDZjZDE1IiwicyI6Ik5UQmpaVGd5T0dZdE5HTTJaaTAwTUdVMUxUa3dZV1l0WVRWbFlURmhZVGt5TnpJeSJ9 &
CF_PID=$!

echo "=== MKOPA LOAN is running ==="
echo "Next.js PID: $NEXT_PID"
echo "Cloudflare Tunnel PID: $CF_PID"
echo "Press Ctrl+C to stop"

# Handle shutdown
trap "echo 'Shutting down...'; kill $NEXT_PID $CF_PID 2>/dev/null; exit 0" SIGINT SIGTERM

# Wait for either process to exit
wait -n $NEXT_PID $CF_PID 2>/dev/null || true
echo "A process has exited. Shutting down..."
kill $NEXT_PID $CF_PID 2>/dev/null || true
