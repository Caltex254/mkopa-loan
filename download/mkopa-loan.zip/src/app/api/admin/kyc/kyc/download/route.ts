import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromRequest();
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (user.role !== 'admin') {
      return NextResponse.json(
        { error: 'Forbidden: Admin access required' },
        { status: 403 }
      );
    }

    const { searchParams } = new URL(request.url);
    const kycId = searchParams.get('kycId');
    const side = searchParams.get('side'); // 'front' or 'back'

    if (!kycId) {
      return NextResponse.json(
        { error: 'Query parameter "kycId" is required' },
        { status: 400 }
      );
    }

    if (!side || !['front', 'back'].includes(side)) {
      return NextResponse.json(
        { error: 'Query parameter "side" must be "front" or "back"' },
        { status: 400 }
      );
    }

    const kyc = await db.kYC.findUnique({
      where: { id: kycId },
      include: {
        user: {
          select: {
            fullName: true,
            nationalId: true,
          },
        },
      },
    });

    if (!kyc) {
      return NextResponse.json(
        { error: 'KYC record not found' },
        { status: 404 }
      );
    }

    const imageData = side === 'front' ? kyc.idFrontImage : kyc.idBackImage;

    if (!imageData) {
      return NextResponse.json(
        { error: 'Image not found' },
        { status: 404 }
      );
    }

    // If it's a base64 data URL, extract the base64 data and content type
    let base64Data = imageData;
    let contentType = 'image/png';

    if (imageData.startsWith('data:')) {
      const matches = imageData.match(/^data:(.+?);base64,(.+)$/);
      if (matches) {
        contentType = matches[1];
        base64Data = matches[2];
      }
    }

    // Convert base64 to buffer
    const buffer = Buffer.from(base64Data, 'base64');

    // Create a filename
    const safeName = (kyc.legalName || kyc.user?.fullName || 'unknown')
      .replace(/[^a-zA-Z0-9]/g, '_')
      .toLowerCase();
    const filename = `${safeName}_id_${side}_${kyc.nationalId || 'unknown'}.png`;

    return new NextResponse(buffer, {
      status: 200,
      headers: {
        'Content-Type': contentType,
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Content-Length': String(buffer.length),
      },
    });
  } catch (error) {
    console.error('KYC document download error:', error);
    return NextResponse.json(
      { error: 'Failed to download document' },
      { status: 500 }
    );
  }
}
